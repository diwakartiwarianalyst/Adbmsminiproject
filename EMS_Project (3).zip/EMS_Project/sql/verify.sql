SET SERVEROUTPUT ON
PROMPT Invalid objects (should be none):
SELECT object_name, object_type, status FROM user_objects WHERE status <> 'VALID';
PROMPT Compilation errors (should be none):
SELECT name, type, line, text FROM user_errors ORDER BY name, sequence;
PROMPT Row counts:
SELECT 'EMPLOYEES' t, COUNT(*) n FROM employees UNION ALL
SELECT 'ATTENDANCE', COUNT(*) FROM attendance UNION ALL
SELECT 'PAYROLL', COUNT(*) FROM payroll UNION ALL
SELECT 'AUDIT_LOG', COUNT(*) FROM audit_log;
