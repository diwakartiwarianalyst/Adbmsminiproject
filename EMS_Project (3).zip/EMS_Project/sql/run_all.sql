-- Run as user EMS from inside this folder:   @run_all
-- (SQL Developer: open this file, press F5. If @ paths fail use EMS_PLSQL_ALL_IN_ONE.sql)
SET SERVEROUTPUT ON SIZE UNLIMITED
@00_cleanup.sql
@01_tables.sql
@02_objects.sql
@03_triggers.sql
@04_pkg_employee.sql
@05_pkg_attendance.sql
@06_pkg_payroll.sql
@07_pkg_perf_sec.sql
@08_pkg_security.sql
@10_pkg_ems_ui.sql
@11_demo.sql
