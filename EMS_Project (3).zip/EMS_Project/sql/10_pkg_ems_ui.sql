-- Console "screens" of the application, written entirely in PL/SQL.
CREATE OR REPLACE PACKAGE pkg_ems_ui AS
  PROCEDURE show_employees(p_name VARCHAR2 DEFAULT NULL);
  PROCEDURE show_dashboard;
  PROCEDURE show_payroll(p_month DATE);
  PROCEDURE show_audit(p_rows NUMBER DEFAULT 20);
END pkg_ems_ui;
/
CREATE OR REPLACE PACKAGE BODY pkg_ems_ui AS

  PROCEDURE hr_line IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 78, '-'));
  END hr_line;

  FUNCTION money(n NUMBER) RETURN VARCHAR2 IS
  BEGIN
    RETURN LPAD(TO_CHAR(NVL(n, 0), 'FM999,999,990.00'), 12);
  END money;

  PROCEDURE show_employees(p_name VARCHAR2 DEFAULT NULL) IS
    c      SYS_REFCURSOR;
    v_id   NUMBER;
    v_name VARCHAR2(100);
    v_mail VARCHAR2(80);
    v_dept VARCHAR2(50);
    v_des  VARCHAR2(50);
    v_cnt  NUMBER := 0;
  BEGIN
    DBMS_OUTPUT.PUT_LINE('EMPLOYEES' || CASE WHEN p_name IS NOT NULL
                         THEN ' matching "' || p_name || '"' END);
    hr_line;
    DBMS_OUTPUT.PUT_LINE(RPAD('ID', 5) || RPAD('NAME', 20) || RPAD('EMAIL', 30) ||
                         RPAD('DEPARTMENT', 17) || 'DESIGNATION');
    hr_line;
    c := pkg_employee.search_employees(p_name);
    LOOP
      FETCH c INTO v_id, v_name, v_mail, v_dept, v_des;
      EXIT WHEN c%NOTFOUND;
      v_cnt := v_cnt + 1;
      DBMS_OUTPUT.PUT_LINE(RPAD(v_id, 5) || RPAD(v_name, 20) || RPAD(v_mail, 30) ||
                           RPAD(v_dept, 17) || v_des);
    END LOOP;
    CLOSE c;
    hr_line;
    DBMS_OUTPUT.PUT_LINE(v_cnt || ' employee(s) found.');
  END show_employees;

  PROCEDURE show_dashboard IS
    v_emp NUMBER;  v_leave NUMBER;  v_adv NUMBER;  v_rating NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_emp   FROM employees WHERE status = 'ACTIVE';
    SELECT COUNT(*) INTO v_leave FROM leaves WHERE status = 'PENDING';
    SELECT COUNT(*) INTO v_adv   FROM salary_advances WHERE status = 'PENDING';
    SELECT NVL(ROUND(AVG(rating), 2), 0) INTO v_rating FROM performance_reviews;
    DBMS_OUTPUT.PUT_LINE('DASHBOARD');
    hr_line;
    DBMS_OUTPUT.PUT_LINE('Active employees        : ' || v_emp);
    DBMS_OUTPUT.PUT_LINE('Pending leave requests  : ' || v_leave);
    DBMS_OUTPUT.PUT_LINE('Pending salary advances : ' || v_adv);
    DBMS_OUTPUT.PUT_LINE('Average rating          : ' || v_rating);
    hr_line;
    DBMS_OUTPUT.PUT_LINE(RPAD('DEPARTMENT', 20) || RPAD('HEADCOUNT', 11) || 'MONTHLY BASIC');
    FOR r IN (SELECT d.dept_name, COUNT(e.emp_id) AS cnt,
                     NVL(SUM(e.basic_salary), 0) AS tot
              FROM   departments d
              LEFT   JOIN employees e ON e.dept_id = d.dept_id AND e.status = 'ACTIVE'
              GROUP  BY d.dept_name ORDER BY d.dept_name)
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(r.dept_name, 20) || RPAD(r.cnt, 11) || money(r.tot));
    END LOOP;
    hr_line;
    DBMS_OUTPUT.PUT_LINE('Net payroll by month');
    FOR r IN (SELECT pay_month, SUM(net_salary) AS tot FROM payroll
              GROUP BY pay_month ORDER BY pay_month)
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(TO_CHAR(r.pay_month, 'MON-YYYY'), 20) || RPAD(' ', 11) || money(r.tot));
    END LOOP;
  END show_dashboard;

  PROCEDURE show_payroll(p_month DATE) IS
    v_total NUMBER := 0;
  BEGIN
    DBMS_OUTPUT.PUT_LINE('PAYROLL REGISTER ' || TO_CHAR(p_month, 'MON-YYYY'));
    hr_line;
    DBMS_OUTPUT.PUT_LINE(RPAD('ID', 4) || RPAD('NAME', 18) || LPAD('BASIC', 11) ||
                         LPAD('OVERTIME', 11) || LPAD('DEDUCTION', 12) || LPAD('NET', 13));
    hr_line;
    FOR r IN (SELECT e.emp_id, e.first_name || ' ' || e.last_name AS nm, p.basic,
                     p.overtime_pay, p.deductions, p.net_salary
              FROM   payroll p JOIN employees e ON e.emp_id = p.emp_id
              WHERE  p.pay_month = TRUNC(p_month, 'MM') ORDER BY e.emp_id)
    LOOP
      v_total := v_total + r.net_salary;
      DBMS_OUTPUT.PUT_LINE(RPAD(r.emp_id, 4) || RPAD(r.nm, 18) || LPAD(TO_CHAR(r.basic, 'FM9,99,990'), 11)
                           || LPAD(TO_CHAR(r.overtime_pay, 'FM99,990.00'), 11)
                           || LPAD(TO_CHAR(r.deductions, 'FM99,990.00'), 12)
                           || LPAD(TO_CHAR(r.net_salary, 'FM9,99,990.00'), 13));
    END LOOP;
    hr_line;
    DBMS_OUTPUT.PUT_LINE('Total net payout: ' || TO_CHAR(v_total, 'FM9,99,99,990.00'));
  END show_payroll;

  PROCEDURE show_audit(p_rows NUMBER DEFAULT 20) IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE('AUDIT LOG (latest ' || p_rows || ')');
    hr_line;
    FOR r IN (SELECT log_id, operation, key_value, new_value, changed_by,
                     TO_CHAR(changed_on, 'DD-MON-YY HH24:MI') AS ts
              FROM   audit_log ORDER BY log_id DESC FETCH FIRST p_rows ROWS ONLY)
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(r.log_id, 5) || RPAD(r.operation, 8) || RPAD(r.key_value, 5) ||
                           RPAD(r.ts, 17) || r.new_value);
    END LOOP;
  END show_audit;

END pkg_ems_ui;
/
