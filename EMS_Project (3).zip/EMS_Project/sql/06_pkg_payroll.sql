CREATE OR REPLACE PACKAGE pkg_payroll AS
  TYPE t_salary IS RECORD (
    basic NUMBER, hra NUMBER, da NUMBER, overtime_pay NUMBER, bonus NUMBER,
    absent_ded NUMBER, pf NUMBER, prof_tax NUMBER, adv_recovery NUMBER,
    gross NUMBER, total_ded NUMBER, net NUMBER);

  FUNCTION  get_working_days(p_month DATE) RETURN NUMBER;
  FUNCTION  calculate_salary(p_emp_id NUMBER, p_month DATE,
                             p_bonus NUMBER DEFAULT 0) RETURN t_salary;
  PROCEDURE generate_payroll(p_month DATE);
  PROCEDURE print_payslip(p_emp_id NUMBER, p_month DATE);
  PROCEDURE request_advance(p_emp_id NUMBER, p_amount NUMBER, p_installments NUMBER);
  PROCEDURE approve_advance(p_adv_id NUMBER, p_approver NUMBER, p_approve BOOLEAN);
END pkg_payroll;
/
CREATE OR REPLACE PACKAGE BODY pkg_payroll AS

  FUNCTION get_working_days(p_month DATE) RETURN NUMBER IS
    v_day DATE   := TRUNC(p_month, 'MM');
    v_end DATE   := LAST_DAY(v_day);
    v_cnt NUMBER := 0;
  BEGIN
    WHILE v_day <= v_end LOOP            -- Monday to Saturday are working days
      IF TO_CHAR(v_day, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') <> 'SUN' THEN
        v_cnt := v_cnt + 1;
      END IF;
      v_day := v_day + 1;
    END LOOP;
    RETURN v_cnt;
  END get_working_days;

  FUNCTION calculate_salary(p_emp_id NUMBER, p_month DATE,
                            p_bonus NUMBER DEFAULT 0) RETURN t_salary IS
    v_sal     t_salary;
    v_start   DATE := TRUNC(p_month, 'MM');
    v_end     DATE := LAST_DAY(TRUNC(p_month, 'MM'));
    v_workdays NUMBER := get_working_days(p_month);
    v_basic   employees.basic_salary%TYPE;
    v_present NUMBER;  v_ot NUMBER;  v_leave NUMBER;  v_absent NUMBER;
    v_daily   NUMBER;
  BEGIN
    SELECT basic_salary INTO v_basic
    FROM   employees WHERE emp_id = p_emp_id AND status = 'ACTIVE';

    SELECT COUNT(*), NVL(SUM(overtime_hours), 0) INTO v_present, v_ot
    FROM   attendance
    WHERE  emp_id = p_emp_id AND att_date BETWEEN v_start AND v_end;

    SELECT NVL(SUM(LEAST(leave_to, v_end) - GREATEST(leave_from, v_start) + 1), 0)
    INTO   v_leave
    FROM   leaves
    WHERE  emp_id = p_emp_id AND status = 'APPROVED'
    AND    leave_to >= v_start AND leave_from <= v_end;

    v_absent := GREATEST(v_workdays - v_present - v_leave, 0);
    v_daily  := v_basic / v_workdays;

    v_sal.basic        := v_basic;
    v_sal.hra          := ROUND(v_basic * 0.20, 2);
    v_sal.da           := ROUND(v_basic * 0.10, 2);
    v_sal.overtime_pay := ROUND(v_ot * (v_basic / (v_workdays * 8)) * 1.5, 2);
    v_sal.bonus        := NVL(p_bonus, 0);
    v_sal.absent_ded   := ROUND(v_absent * v_daily, 2);
    v_sal.pf           := ROUND(v_basic * 0.12, 2);
    v_sal.prof_tax     := 200;

    SELECT NVL(SUM(LEAST(monthly_recovery, balance)), 0) INTO v_sal.adv_recovery
    FROM   salary_advances
    WHERE  emp_id = p_emp_id AND status = 'APPROVED' AND balance > 0;

    v_sal.gross     := v_sal.basic + v_sal.hra + v_sal.da
                       + v_sal.overtime_pay + v_sal.bonus;
    v_sal.total_ded := v_sal.absent_ded + v_sal.pf + v_sal.prof_tax
                       + v_sal.adv_recovery;
    v_sal.net       := v_sal.gross - v_sal.total_ded;
    RETURN v_sal;
  END calculate_salary;

  PROCEDURE generate_payroll(p_month DATE) IS
    v_sal   t_salary;
    v_month DATE   := TRUNC(p_month, 'MM');
    v_done  NUMBER := 0;
    v_skip  NUMBER := 0;
  BEGIN
    FOR emp IN (SELECT emp_id FROM employees WHERE status = 'ACTIVE') LOOP
      BEGIN
        SAVEPOINT sp_emp;
        v_sal := calculate_salary(emp.emp_id, v_month);

        INSERT INTO payroll(emp_id, pay_month, basic, hra, da, overtime_pay,
                            bonus, deductions, net_salary)
        VALUES (emp.emp_id, v_month, v_sal.basic, v_sal.hra, v_sal.da,
                v_sal.overtime_pay, v_sal.bonus, v_sal.total_ded, v_sal.net);

        UPDATE salary_advances
        SET    balance = balance - LEAST(monthly_recovery, balance),
               status  = CASE WHEN balance - LEAST(monthly_recovery, balance) <= 0
                              THEN 'CLOSED' ELSE status END
        WHERE  emp_id = emp.emp_id AND status = 'APPROVED' AND balance > 0;
        v_done := v_done + 1;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN       -- payroll already generated for this month
          ROLLBACK TO sp_emp;
          v_skip := v_skip + 1;
      END;
    END LOOP;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Payroll generated: ' || v_done || ', skipped: ' || v_skip);
  END generate_payroll;

  PROCEDURE print_payslip(p_emp_id NUMBER, p_month DATE) IS
    v_p    payroll%ROWTYPE;
    v_name VARCHAR2(100);
    v_dept departments.dept_name%TYPE;
    FUNCTION f(n NUMBER) RETURN VARCHAR2 IS
    BEGIN RETURN LPAD(TO_CHAR(n, 'FM9,999,990.00'), 12); END;
  BEGIN
    SELECT * INTO v_p FROM payroll
    WHERE  emp_id = p_emp_id AND pay_month = TRUNC(p_month, 'MM');
    SELECT e.first_name || ' ' || e.last_name, d.dept_name INTO v_name, v_dept
    FROM   employees e JOIN departments d ON d.dept_id = e.dept_id
    WHERE  e.emp_id = p_emp_id;

    DBMS_OUTPUT.PUT_LINE('PAYSLIP FOR ' || TO_CHAR(v_p.pay_month, 'MON-YYYY'));
    DBMS_OUTPUT.PUT_LINE('Employee : ' || v_name || ' (' || v_dept || ')');
    DBMS_OUTPUT.PUT_LINE('Basic            ' || f(v_p.basic));
    DBMS_OUTPUT.PUT_LINE('HRA              ' || f(v_p.hra));
    DBMS_OUTPUT.PUT_LINE('DA               ' || f(v_p.da));
    DBMS_OUTPUT.PUT_LINE('Overtime pay     ' || f(v_p.overtime_pay));
    DBMS_OUTPUT.PUT_LINE('Bonus            ' || f(v_p.bonus));
    DBMS_OUTPUT.PUT_LINE('Total deductions ' || f(v_p.deductions));
    DBMS_OUTPUT.PUT_LINE('NET SALARY       ' || f(v_p.net_salary));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20020, 'Payroll not generated for this employee/month');
  END print_payslip;

  PROCEDURE request_advance(p_emp_id NUMBER, p_amount NUMBER, p_installments NUMBER) IS
    v_basic employees.basic_salary%TYPE;
    v_open  NUMBER;
  BEGIN
    SELECT basic_salary INTO v_basic
    FROM   employees WHERE emp_id = p_emp_id AND status = 'ACTIVE';
    IF p_amount <= 0 OR p_installments < 1 THEN
      RAISE_APPLICATION_ERROR(-20030, 'Invalid amount or number of installments');
    END IF;
    IF p_amount > 2 * v_basic THEN
      RAISE_APPLICATION_ERROR(-20031, 'Advance cannot exceed two months basic salary');
    END IF;
    SELECT COUNT(*) INTO v_open FROM salary_advances
    WHERE  emp_id = p_emp_id AND status IN ('PENDING', 'APPROVED');
    IF v_open > 0 THEN
      RAISE_APPLICATION_ERROR(-20032, 'An earlier advance is still open');
    END IF;
    INSERT INTO salary_advances(emp_id, amount, balance, monthly_recovery)
    VALUES (p_emp_id, p_amount, p_amount, ROUND(p_amount / p_installments, 2));
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20033, 'Active employee not found');
  END request_advance;

  PROCEDURE approve_advance(p_adv_id NUMBER, p_approver NUMBER, p_approve BOOLEAN) IS
    v_status salary_advances.status%TYPE;
    v_new    salary_advances.status%TYPE;
    e_locked EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_locked, -54);
  BEGIN
    SELECT status INTO v_status FROM salary_advances
    WHERE  adv_id = p_adv_id FOR UPDATE NOWAIT;      -- row lock against double approval
    IF v_status <> 'PENDING' THEN
      RAISE_APPLICATION_ERROR(-20034, 'Request has already been processed');
    END IF;
    v_new := CASE WHEN p_approve THEN 'APPROVED' ELSE 'REJECTED' END;
    UPDATE salary_advances
    SET    status = v_new, approved_by = p_approver, decided_on = SYSDATE
    WHERE  adv_id = p_adv_id;
    COMMIT;
  EXCEPTION
    WHEN e_locked THEN
      RAISE_APPLICATION_ERROR(-20035, 'Request is being processed by another user');
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20036, 'Advance request not found');
  END approve_advance;

END pkg_payroll;
/
