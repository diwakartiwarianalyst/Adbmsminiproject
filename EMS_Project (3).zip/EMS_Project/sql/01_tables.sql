CREATE TABLE departments (
  dept_id    NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  dept_name  VARCHAR2(50) NOT NULL UNIQUE,
  location   VARCHAR2(50)
);

CREATE TABLE designations (
  desig_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title      VARCHAR2(50) NOT NULL UNIQUE,
  min_salary NUMBER(10,2) NOT NULL,
  max_salary NUMBER(10,2) NOT NULL,
  CONSTRAINT ck_desig_sal CHECK (max_salary >= min_salary)
);

CREATE TABLE employees (
  emp_id       NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  first_name   VARCHAR2(40) NOT NULL,
  last_name    VARCHAR2(40) NOT NULL,
  email        VARCHAR2(80) NOT NULL UNIQUE,
  phone        VARCHAR2(15),
  hire_date    DATE DEFAULT SYSDATE NOT NULL,
  dept_id      NUMBER NOT NULL REFERENCES departments(dept_id),
  desig_id     NUMBER NOT NULL REFERENCES designations(desig_id),
  manager_id   NUMBER REFERENCES employees(emp_id),
  basic_salary NUMBER(10,2) NOT NULL CHECK (basic_salary > 0),
  status       VARCHAR2(10) DEFAULT 'ACTIVE' NOT NULL
               CHECK (status IN ('ACTIVE','INACTIVE')),
  CONSTRAINT ck_emp_email CHECK (REGEXP_LIKE(email, '^[^@ ]+@[^@ ]+\.[A-Za-z]{2,}$'))
);

CREATE TABLE roles (
  role_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  role_name VARCHAR2(20) NOT NULL UNIQUE
);

CREATE TABLE users_auth (
  user_id         NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id          NUMBER NOT NULL UNIQUE REFERENCES employees(emp_id),
  role_id         NUMBER NOT NULL REFERENCES roles(role_id),
  username        VARCHAR2(30) NOT NULL UNIQUE,
  salt            VARCHAR2(32) NOT NULL,
  pwd_hash        VARCHAR2(64) NOT NULL,
  failed_attempts NUMBER(2) DEFAULT 0 NOT NULL,
  last_login      TIMESTAMP
);

CREATE TABLE attendance (
  att_id         NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id         NUMBER NOT NULL REFERENCES employees(emp_id),
  att_date       DATE NOT NULL,
  in_time        TIMESTAMP NOT NULL,
  out_time       TIMESTAMP,
  work_hours     NUMBER(5,2) DEFAULT 0,
  overtime_hours NUMBER(5,2) DEFAULT 0,
  CONSTRAINT uq_att_emp_day UNIQUE (emp_id, att_date),
  CONSTRAINT ck_att_time CHECK (out_time IS NULL OR out_time > in_time)
);

CREATE TABLE leaves (
  leave_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id     NUMBER NOT NULL REFERENCES employees(emp_id),
  leave_type VARCHAR2(10) NOT NULL CHECK (leave_type IN ('CASUAL','SICK','EARNED')),
  leave_from DATE NOT NULL,
  leave_to   DATE NOT NULL,
  status     VARCHAR2(10) DEFAULT 'PENDING' NOT NULL
             CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  CONSTRAINT ck_leave_dates CHECK (leave_to >= leave_from)
);

CREATE TABLE payroll (
  payroll_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id       NUMBER NOT NULL REFERENCES employees(emp_id),
  pay_month    DATE NOT NULL,
  basic        NUMBER(12,2) NOT NULL,
  hra          NUMBER(12,2) NOT NULL,
  da           NUMBER(12,2) NOT NULL,
  overtime_pay NUMBER(12,2) DEFAULT 0 NOT NULL,
  bonus        NUMBER(12,2) DEFAULT 0 NOT NULL,
  deductions   NUMBER(12,2) DEFAULT 0 NOT NULL,
  net_salary   NUMBER(12,2) NOT NULL,
  generated_on DATE DEFAULT SYSDATE NOT NULL,
  CONSTRAINT uq_pay_emp_month UNIQUE (emp_id, pay_month)
);

CREATE TABLE salary_advances (
  adv_id           NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id           NUMBER NOT NULL REFERENCES employees(emp_id),
  amount           NUMBER(10,2) NOT NULL CHECK (amount > 0),
  balance          NUMBER(10,2) NOT NULL,
  monthly_recovery NUMBER(10,2) NOT NULL,
  request_date     DATE DEFAULT SYSDATE NOT NULL,
  status           VARCHAR2(10) DEFAULT 'PENDING' NOT NULL
                   CHECK (status IN ('PENDING','APPROVED','REJECTED','CLOSED')),
  approved_by      NUMBER REFERENCES employees(emp_id),
  decided_on       DATE
);

CREATE TABLE performance_reviews (
  review_id     NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id        NUMBER NOT NULL REFERENCES employees(emp_id),
  reviewer_id   NUMBER NOT NULL REFERENCES employees(emp_id),
  review_period VARCHAR2(10) NOT NULL,
  review_date   DATE DEFAULT SYSDATE NOT NULL,
  rating        NUMBER(2,1) NOT NULL CHECK (rating BETWEEN 1 AND 5),
  feedback      VARCHAR2(500),
  CONSTRAINT ck_rev_self CHECK (emp_id <> reviewer_id),
  CONSTRAINT uq_review UNIQUE (emp_id, reviewer_id, review_period)
);

CREATE TABLE audit_log (
  log_id     NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  table_name VARCHAR2(30) NOT NULL,
  operation  VARCHAR2(10) NOT NULL,
  key_value  NUMBER,
  old_value  VARCHAR2(400),
  new_value  VARCHAR2(400),
  changed_by VARCHAR2(30),
  changed_on TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL
);
