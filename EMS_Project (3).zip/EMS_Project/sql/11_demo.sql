-- Complete automatic demonstration written in PL/SQL.
-- Seeds master data, simulates a month of attendance, runs payroll, advances,
-- reviews, security and audit, and prints every result with DBMS_OUTPUT.
SET SERVEROUTPUT ON SIZE UNLIMITED
SET VERIFY OFF

PROMPT ===== STEP 1: Master data =====
BEGIN
  INSERT INTO departments(dept_name, location) VALUES ('IT', 'Ludhiana');
  INSERT INTO departments(dept_name, location) VALUES ('Human Resources', 'Ludhiana');
  INSERT INTO departments(dept_name, location) VALUES ('Finance', 'Chandigarh');
  INSERT INTO designations(title, min_salary, max_salary) VALUES ('Software Engineer', 30000, 90000);
  INSERT INTO designations(title, min_salary, max_salary) VALUES ('HR Executive', 25000, 60000);
  INSERT INTO designations(title, min_salary, max_salary) VALUES ('Accountant', 25000, 70000);
  INSERT INTO designations(title, min_salary, max_salary) VALUES ('Manager', 60000, 150000);
  INSERT INTO roles(role_name) VALUES ('HR');
  INSERT INTO roles(role_name) VALUES ('MANAGER');
  INSERT INTO roles(role_name) VALUES ('EMPLOYEE');
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('3 departments, 4 designations and 3 roles inserted.');
END;
/

PROMPT ===== STEP 2: Add employees (pkg_employee.add_employee) =====
DECLARE
  v_id  NUMBER;
  v_mgr NUMBER;
  PROCEDURE hire(p_f VARCHAR2, p_l VARCHAR2, p_dept NUMBER, p_des NUMBER,
                 p_sal NUMBER, p_manager NUMBER) IS
  BEGIN
    pkg_employee.add_employee(p_f, p_l, p_f || '.' || p_l || '@example.com',
                              '98765' || LPAD(TRUNC(DBMS_RANDOM.VALUE(0, 99999)), 5, '0'),
                              p_dept, p_des, p_manager, p_sal, v_id);
    DBMS_OUTPUT.PUT_LINE('Added employee ' || v_id || ': ' || INITCAP(p_f) || ' ' || INITCAP(p_l));
  END hire;
BEGIN
  hire('rajesh',   'verma',  1, 4, 110000, NULL);
  v_mgr := v_id;
  hire('amit',     'sharma', 1, 1,  65000, v_mgr);
  hire('neha',     'kapoor', 2, 2,  42000, v_mgr);
  hire('simran',   'kaur',   3, 3,  48000, v_mgr);
  hire('harpreet', 'singh',  1, 1,  72000, v_mgr);
  hire('jaspal',   'gill',   3, 3,  39000, v_mgr);
END;
/

PROMPT ===== STEP 3: Business-rule check (salary above designation maximum) =====
DECLARE
  v_id NUMBER;
BEGIN
  pkg_employee.add_employee('Test', 'User', 'test.user@example.com', NULL, 1, 1, 1, 200000, v_id);
EXCEPTION
  WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Rejected as expected -> ' || SQLERRM);
END;
/

PROMPT ===== STEP 4: Simulate attendance for September 2026 (trigger computes hours) =====
DECLARE
  v_start DATE := DATE '2026-09-01';
  v_day   DATE;
  v_hours NUMBER;
  v_rows  NUMBER := 0;
BEGIN
  FOR e IN (SELECT emp_id FROM employees WHERE status = 'ACTIVE') LOOP
    FOR i IN 0 .. 29 LOOP
      v_day := v_start + i;
      IF TO_CHAR(v_day, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') <> 'SUN'
         AND MOD(i + e.emp_id, 11) <> 0 THEN           -- an occasional absence
        v_hours := 7.5 + MOD(i * e.emp_id, 4) * 0.5;    -- 7.5 to 9.0 hours
        INSERT INTO attendance(emp_id, att_date, in_time, out_time)
        VALUES (e.emp_id, v_day,
                CAST(v_day + 9/24 AS TIMESTAMP),
                CAST(v_day + 9/24 + v_hours/24 AS TIMESTAMP));
        v_rows := v_rows + 1;
      END IF;
    END LOOP;
  END LOOP;
  INSERT INTO leaves(emp_id, leave_type, leave_from, leave_to, status)
  VALUES (2, 'SICK', DATE '2026-09-02', DATE '2026-09-02', 'APPROVED');
  COMMIT;
  DBMS_OUTPUT.PUT_LINE(v_rows || ' attendance rows inserted; 1 approved leave for employee 2.');
END;
/

PROMPT ===== STEP 5: Monthly attendance summary and report =====
DECLARE
  v_days NUMBER; v_hrs NUMBER; v_ot NUMBER; v_lv NUMBER;
BEGIN
  pkg_attendance.monthly_summary(2, DATE '2026-09-01', v_days, v_hrs, v_ot, v_lv);
  DBMS_OUTPUT.PUT_LINE('Employee 2 -> days: ' || v_days || ', hours: ' || v_hrs ||
                       ', overtime: ' || v_ot || ', leave days: ' || v_lv);
  DBMS_OUTPUT.PUT_LINE(' ');
  pkg_attendance.attendance_report(DATE '2026-09-01');
END;
/

PROMPT ===== STEP 6: Generate payroll (run twice to prove it is idempotent) =====
BEGIN
  pkg_payroll.generate_payroll(DATE '2026-09-01');
  pkg_payroll.generate_payroll(DATE '2026-09-01');
END;
/
BEGIN
  pkg_ems_ui.show_payroll(DATE '2026-09-01');
  DBMS_OUTPUT.PUT_LINE(' ');
  pkg_payroll.print_payslip(2, DATE '2026-09-01');
END;
/

PROMPT ===== STEP 7: Salary advance workflow =====
DECLARE
  v_sal pkg_payroll.t_salary;
BEGIN
  pkg_payroll.request_advance(2, 50000, 5);
  DBMS_OUTPUT.PUT_LINE('Advance requested by employee 2.');
  BEGIN
    pkg_payroll.request_advance(2, 10000, 2);
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Second request rejected -> ' || SQLERRM);
  END;
  pkg_payroll.approve_advance(1, 1, TRUE);
  DBMS_OUTPUT.PUT_LINE('Advance approved by manager (employee 1).');
  BEGIN
    pkg_payroll.approve_advance(1, 1, TRUE);
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Double approval rejected -> ' || SQLERRM);
  END;
  v_sal := pkg_payroll.calculate_salary(2, DATE '2026-10-01');
  DBMS_OUTPUT.PUT_LINE('October advance recovery for employee 2: ' || v_sal.adv_recovery);
END;
/

PROMPT ===== STEP 8: Performance reviews and ranking =====
BEGIN
  pkg_performance.record_review(2, 1, '2026-H1', 4.6, 'Excellent delivery');
  pkg_performance.record_review(5, 1, '2026-H1', 4.2, 'Consistent');
  pkg_performance.record_review(3, 1, '2026-H1', 4.4, 'Strong team player');
  pkg_performance.record_review(4, 1, '2026-H1', 4.1, 'Accurate and timely');
  pkg_performance.record_review(6, 1, '2026-H1', 3.8, 'Needs improvement in reports');
  pkg_performance.performance_report('2026-H1');
  DBMS_OUTPUT.PUT_LINE('Employee 2 promotion eligible: ' ||
    CASE WHEN pkg_performance.promotion_eligible(2) THEN 'YES' ELSE 'NO' END);
END;
/

PROMPT ===== STEP 9: Security - registration, login and lockout =====
DECLARE
  v_res VARCHAR2(20);
BEGIN
  pkg_security.register_user(1, 'rajesh', 'Secret#123', 1);
  pkg_security.register_user(2, 'amit',   'Welcome@45', 3);
  DBMS_OUTPUT.PUT_LINE('amit / correct password -> ' || pkg_security.authenticate('amit', 'Welcome@45'));
  DBMS_OUTPUT.PUT_LINE('amit / wrong password   -> ' || pkg_security.authenticate('amit', 'wrong'));
  FOR i IN 1 .. 4 LOOP
    v_res := pkg_security.authenticate('amit', 'wrong');
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('after 5 failures, correct password -> ' || pkg_security.authenticate('amit', 'Welcome@45'));
END;
/

PROMPT ===== STEP 10: Update, soft delete and audit trail =====
BEGIN
  pkg_employee.update_employee(5, p_salary => 78000);
  pkg_employee.remove_employee(6);
  BEGIN
    DELETE FROM employees WHERE emp_id = 1;
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Physical delete blocked -> ' || SQLERRM);
  END;
  ROLLBACK;
  pkg_ems_ui.show_audit(8);
END;
/

PROMPT ===== STEP 11: Dashboard =====
BEGIN
  pkg_ems_ui.show_dashboard;
  pkg_ems_ui.show_employees;
END;
/
PROMPT ===== DEMO COMPLETE =====
