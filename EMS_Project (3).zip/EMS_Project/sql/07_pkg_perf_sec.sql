CREATE OR REPLACE PACKAGE pkg_performance AS
  PROCEDURE record_review(p_emp_id NUMBER, p_reviewer_id NUMBER,
                          p_period VARCHAR2, p_rating NUMBER, p_feedback VARCHAR2);
  PROCEDURE performance_report(p_period VARCHAR2);
  FUNCTION  promotion_eligible(p_emp_id NUMBER) RETURN BOOLEAN;
END pkg_performance;
/
CREATE OR REPLACE PACKAGE BODY pkg_performance AS

  PROCEDURE record_review(p_emp_id NUMBER, p_reviewer_id NUMBER,
                          p_period VARCHAR2, p_rating NUMBER, p_feedback VARCHAR2) IS
  BEGIN
    INSERT INTO performance_reviews(emp_id, reviewer_id, review_period, rating, feedback)
    VALUES (p_emp_id, p_reviewer_id, p_period, p_rating, p_feedback);
    COMMIT;
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(-20040, 'Review already recorded for this period');
  END record_review;

  PROCEDURE performance_report(p_period VARCHAR2) IS
    CURSOR c_rank IS
      SELECT d.dept_name, e.first_name || ' ' || e.last_name AS emp_name,
             ROUND(AVG(r.rating), 2) AS avg_rating,
             RANK() OVER (PARTITION BY e.dept_id
                          ORDER BY AVG(r.rating) DESC) AS dept_rank
      FROM   performance_reviews r
      JOIN   employees   e ON e.emp_id  = r.emp_id
      JOIN   departments d ON d.dept_id = e.dept_id
      WHERE  r.review_period = p_period
      GROUP  BY d.dept_name, e.dept_id, e.emp_id, e.first_name, e.last_name
      ORDER  BY d.dept_name, dept_rank;
  BEGIN
    FOR rec IN c_rank LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(rec.dept_name, 14) || RPAD(rec.emp_name, 22) ||
                           RPAD(rec.avg_rating, 8) || '#' || rec.dept_rank);
    END LOOP;
  END performance_report;

  FUNCTION promotion_eligible(p_emp_id NUMBER) RETURN BOOLEAN IS
    v_avg NUMBER;
  BEGIN
    SELECT AVG(rating) INTO v_avg
    FROM  (SELECT rating FROM performance_reviews
           WHERE  emp_id = p_emp_id
           ORDER  BY review_date DESC
           FETCH FIRST 2 ROWS ONLY);
    RETURN NVL(v_avg, 0) >= 4.5;
  END promotion_eligible;

END pkg_performance;
/
