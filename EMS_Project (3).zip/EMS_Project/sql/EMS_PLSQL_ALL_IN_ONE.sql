-- Removes every EMS object from the CURRENT schema so the project can be re-run.
-- Safe to run when nothing exists (errors are ignored).
SET SERVEROUTPUT ON
BEGIN
  FOR r IN (SELECT object_name, object_type FROM user_objects
            WHERE  object_type IN ('PACKAGE','VIEW','MATERIALIZED VIEW'))
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP ' || r.object_type || ' ' || r.object_name;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
  FOR r IN (SELECT table_name FROM user_tables
            WHERE  table_name IN ('AUDIT_LOG','PERFORMANCE_REVIEWS','SALARY_ADVANCES',
                                  'PAYROLL','LEAVES','ATTENDANCE','USERS_AUTH','ROLES',
                                  'EMPLOYEES','DESIGNATIONS','DEPARTMENTS'))
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE ' || r.table_name || ' CASCADE CONSTRAINTS PURGE';
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('Cleanup finished.');
END;
/
CREATE TABLE departments (
  dept_id    NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  dept_name  VARCHAR2(50) NOT NULL UNIQUE,
  location   VARCHAR2(50)
);

CREATE TABLE designations (
  desig_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title      VARCHAR2(50) NOT NULL UNIQUE,
  min_salary NUMBER(10,2) NOT NULL,
  max_salary NUMBER(10,2) NOT NULL,
  CONSTRAINT ck_desig_sal CHECK (max_salary >= min_salary)
);

CREATE TABLE employees (
  emp_id       NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  first_name   VARCHAR2(40) NOT NULL,
  last_name    VARCHAR2(40) NOT NULL,
  email        VARCHAR2(80) NOT NULL UNIQUE,
  phone        VARCHAR2(15),
  hire_date    DATE DEFAULT SYSDATE NOT NULL,
  dept_id      NUMBER NOT NULL REFERENCES departments(dept_id),
  desig_id     NUMBER NOT NULL REFERENCES designations(desig_id),
  manager_id   NUMBER REFERENCES employees(emp_id),
  basic_salary NUMBER(10,2) NOT NULL CHECK (basic_salary > 0),
  status       VARCHAR2(10) DEFAULT 'ACTIVE' NOT NULL
               CHECK (status IN ('ACTIVE','INACTIVE')),
  CONSTRAINT ck_emp_email CHECK (REGEXP_LIKE(email, '^[^@ ]+@[^@ ]+\.[A-Za-z]{2,}$'))
);

CREATE TABLE roles (
  role_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  role_name VARCHAR2(20) NOT NULL UNIQUE
);

CREATE TABLE users_auth (
  user_id         NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id          NUMBER NOT NULL UNIQUE REFERENCES employees(emp_id),
  role_id         NUMBER NOT NULL REFERENCES roles(role_id),
  username        VARCHAR2(30) NOT NULL UNIQUE,
  salt            VARCHAR2(32) NOT NULL,
  pwd_hash        VARCHAR2(64) NOT NULL,
  failed_attempts NUMBER(2) DEFAULT 0 NOT NULL,
  last_login      TIMESTAMP
);

CREATE TABLE attendance (
  att_id         NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id         NUMBER NOT NULL REFERENCES employees(emp_id),
  att_date       DATE NOT NULL,
  in_time        TIMESTAMP NOT NULL,
  out_time       TIMESTAMP,
  work_hours     NUMBER(5,2) DEFAULT 0,
  overtime_hours NUMBER(5,2) DEFAULT 0,
  CONSTRAINT uq_att_emp_day UNIQUE (emp_id, att_date),
  CONSTRAINT ck_att_time CHECK (out_time IS NULL OR out_time > in_time)
);

CREATE TABLE leaves (
  leave_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id     NUMBER NOT NULL REFERENCES employees(emp_id),
  leave_type VARCHAR2(10) NOT NULL CHECK (leave_type IN ('CASUAL','SICK','EARNED')),
  leave_from DATE NOT NULL,
  leave_to   DATE NOT NULL,
  status     VARCHAR2(10) DEFAULT 'PENDING' NOT NULL
             CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  CONSTRAINT ck_leave_dates CHECK (leave_to >= leave_from)
);

CREATE TABLE payroll (
  payroll_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id       NUMBER NOT NULL REFERENCES employees(emp_id),
  pay_month    DATE NOT NULL,
  basic        NUMBER(12,2) NOT NULL,
  hra          NUMBER(12,2) NOT NULL,
  da           NUMBER(12,2) NOT NULL,
  overtime_pay NUMBER(12,2) DEFAULT 0 NOT NULL,
  bonus        NUMBER(12,2) DEFAULT 0 NOT NULL,
  deductions   NUMBER(12,2) DEFAULT 0 NOT NULL,
  net_salary   NUMBER(12,2) NOT NULL,
  generated_on DATE DEFAULT SYSDATE NOT NULL,
  CONSTRAINT uq_pay_emp_month UNIQUE (emp_id, pay_month)
);

CREATE TABLE salary_advances (
  adv_id           NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id           NUMBER NOT NULL REFERENCES employees(emp_id),
  amount           NUMBER(10,2) NOT NULL CHECK (amount > 0),
  balance          NUMBER(10,2) NOT NULL,
  monthly_recovery NUMBER(10,2) NOT NULL,
  request_date     DATE DEFAULT SYSDATE NOT NULL,
  status           VARCHAR2(10) DEFAULT 'PENDING' NOT NULL
                   CHECK (status IN ('PENDING','APPROVED','REJECTED','CLOSED')),
  approved_by      NUMBER REFERENCES employees(emp_id),
  decided_on       DATE
);

CREATE TABLE performance_reviews (
  review_id     NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  emp_id        NUMBER NOT NULL REFERENCES employees(emp_id),
  reviewer_id   NUMBER NOT NULL REFERENCES employees(emp_id),
  review_period VARCHAR2(10) NOT NULL,
  review_date   DATE DEFAULT SYSDATE NOT NULL,
  rating        NUMBER(2,1) NOT NULL CHECK (rating BETWEEN 1 AND 5),
  feedback      VARCHAR2(500),
  CONSTRAINT ck_rev_self CHECK (emp_id <> reviewer_id),
  CONSTRAINT uq_review UNIQUE (emp_id, reviewer_id, review_period)
);

CREATE TABLE audit_log (
  log_id     NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  table_name VARCHAR2(30) NOT NULL,
  operation  VARCHAR2(10) NOT NULL,
  key_value  NUMBER,
  old_value  VARCHAR2(400),
  new_value  VARCHAR2(400),
  changed_by VARCHAR2(30),
  changed_on TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL
);
-- Indexes
CREATE INDEX idx_emp_dept   ON employees(dept_id);
CREATE INDEX idx_emp_desig  ON employees(desig_id);
CREATE INDEX idx_emp_lname  ON employees(UPPER(last_name));
CREATE INDEX idx_leave_emp  ON leaves(emp_id, leave_from, leave_to);
CREATE INDEX idx_pay_month  ON payroll(pay_month);

-- View hiding salary and other sensitive columns
CREATE OR REPLACE VIEW v_employee_details AS
SELECT e.emp_id,
       e.first_name || ' ' || e.last_name AS full_name,
       e.email, e.phone, d.dept_name,
       g.title AS designation, e.hire_date, e.status
FROM   employees e
JOIN   departments d  ON d.dept_id  = e.dept_id
JOIN   designations g ON g.desig_id = e.desig_id;

-- Materialized view for department-wise payroll analysis
CREATE MATERIALIZED VIEW mv_dept_payroll
BUILD IMMEDIATE REFRESH COMPLETE ON DEMAND AS
SELECT e.dept_id, p.pay_month,
       COUNT(*)          AS headcount,
       SUM(p.net_salary) AS total_net
FROM   payroll p JOIN employees e ON e.emp_id = p.emp_id
GROUP  BY e.dept_id, p.pay_month;
-- Computes working hours and overtime when an employee checks out
CREATE OR REPLACE TRIGGER trg_att_hours
BEFORE INSERT OR UPDATE OF out_time ON attendance
FOR EACH ROW
WHEN (NEW.out_time IS NOT NULL)
DECLARE
  v_hours NUMBER;
BEGIN
  v_hours := ROUND(
      EXTRACT(DAY    FROM (:NEW.out_time - :NEW.in_time)) * 24
    + EXTRACT(HOUR   FROM (:NEW.out_time - :NEW.in_time))
    + EXTRACT(MINUTE FROM (:NEW.out_time - :NEW.in_time)) / 60, 2);
  :NEW.work_hours     := v_hours;
  :NEW.overtime_hours := GREATEST(v_hours - 8, 0);
END trg_att_hours;
/

-- Audit trail for employee inserts and updates
CREATE OR REPLACE TRIGGER trg_emp_audit
AFTER INSERT OR UPDATE ON employees
FOR EACH ROW
DECLARE
  v_op  VARCHAR2(10);
  v_old VARCHAR2(400);
  v_new VARCHAR2(400);
BEGIN
  IF INSERTING THEN
    v_op  := 'INSERT';
  ELSE
    v_op  := 'UPDATE';
    v_old := 'dept=' || :OLD.dept_id || ';desig=' || :OLD.desig_id
             || ';salary=' || :OLD.basic_salary || ';status=' || :OLD.status;
  END IF;
  v_new := 'dept=' || :NEW.dept_id || ';desig=' || :NEW.desig_id
           || ';salary=' || :NEW.basic_salary || ';status=' || :NEW.status;
  INSERT INTO audit_log(table_name, operation, key_value, old_value, new_value, changed_by)
  VALUES ('EMPLOYEES', v_op, :NEW.emp_id, v_old, v_new,
          SYS_CONTEXT('USERENV', 'SESSION_USER'));
END trg_emp_audit;
/

-- Physical deletion is blocked: employees are retired by setting status = INACTIVE
CREATE OR REPLACE TRIGGER trg_emp_no_delete
BEFORE DELETE ON employees
BEGIN
  RAISE_APPLICATION_ERROR(-20099,
    'Employees cannot be deleted. Use pkg_employee.remove_employee.');
END trg_emp_no_delete;
/
CREATE OR REPLACE PACKAGE pkg_employee AS
  PROCEDURE add_employee(p_first VARCHAR2, p_last VARCHAR2, p_email VARCHAR2,
                         p_phone VARCHAR2, p_dept_id NUMBER, p_desig_id NUMBER,
                         p_manager_id NUMBER, p_salary NUMBER, p_emp_id OUT NUMBER);
  PROCEDURE update_employee(p_emp_id NUMBER, p_phone VARCHAR2 DEFAULT NULL,
                            p_dept_id NUMBER DEFAULT NULL,
                            p_desig_id NUMBER DEFAULT NULL,
                            p_salary NUMBER DEFAULT NULL);
  PROCEDURE remove_employee(p_emp_id NUMBER);
  FUNCTION search_employees(p_name VARCHAR2 DEFAULT NULL,
                            p_dept_id NUMBER DEFAULT NULL,
                            p_desig_id NUMBER DEFAULT NULL) RETURN SYS_REFCURSOR;
END pkg_employee;
/
CREATE OR REPLACE PACKAGE BODY pkg_employee AS

  PROCEDURE add_employee(p_first VARCHAR2, p_last VARCHAR2, p_email VARCHAR2,
                         p_phone VARCHAR2, p_dept_id NUMBER, p_desig_id NUMBER,
                         p_manager_id NUMBER, p_salary NUMBER, p_emp_id OUT NUMBER) IS
    v_min designations.min_salary%TYPE;
    v_max designations.max_salary%TYPE;
  BEGIN
    SELECT min_salary, max_salary INTO v_min, v_max
    FROM   designations WHERE desig_id = p_desig_id;

    IF p_salary NOT BETWEEN v_min AND v_max THEN
      RAISE_APPLICATION_ERROR(-20001, 'Salary is outside the range for this designation');
    END IF;

    INSERT INTO employees(first_name, last_name, email, phone, dept_id,
                          desig_id, manager_id, basic_salary)
    VALUES (INITCAP(p_first), INITCAP(p_last), LOWER(p_email), p_phone,
            p_dept_id, p_desig_id, p_manager_id, p_salary)
    RETURNING emp_id INTO p_emp_id;
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20002, 'Invalid designation id');
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(-20003, 'An employee with this email already exists');
  END add_employee;

  PROCEDURE update_employee(p_emp_id NUMBER, p_phone VARCHAR2 DEFAULT NULL,
                            p_dept_id NUMBER DEFAULT NULL,
                            p_desig_id NUMBER DEFAULT NULL,
                            p_salary NUMBER DEFAULT NULL) IS
  BEGIN
    UPDATE employees
    SET    phone        = NVL(p_phone,   phone),
           dept_id      = NVL(p_dept_id, dept_id),
           desig_id     = NVL(p_desig_id, desig_id),
           basic_salary = NVL(p_salary,  basic_salary)
    WHERE  emp_id = p_emp_id AND status = 'ACTIVE';
    IF SQL%ROWCOUNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20004, 'Active employee not found');
    END IF;
    COMMIT;
  END update_employee;

  PROCEDURE remove_employee(p_emp_id NUMBER) IS
  BEGIN
    UPDATE employees SET status = 'INACTIVE'
    WHERE  emp_id = p_emp_id AND status = 'ACTIVE';
    IF SQL%ROWCOUNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20005, 'Active employee not found');
    END IF;
    COMMIT;
  END remove_employee;

  FUNCTION search_employees(p_name VARCHAR2 DEFAULT NULL,
                            p_dept_id NUMBER DEFAULT NULL,
                            p_desig_id NUMBER DEFAULT NULL) RETURN SYS_REFCURSOR IS
    v_cur SYS_REFCURSOR;
  BEGIN
    OPEN v_cur FOR
      SELECT emp_id, full_name, email, dept_name, designation
      FROM   v_employee_details v
      WHERE  status = 'ACTIVE'
      AND   (p_name IS NULL OR UPPER(full_name) LIKE '%' || UPPER(p_name) || '%')
      AND   (p_dept_id  IS NULL OR dept_name   = (SELECT dept_name FROM departments
                                                   WHERE dept_id = p_dept_id))
      AND   (p_desig_id IS NULL OR designation = (SELECT title FROM designations
                                                   WHERE desig_id = p_desig_id))
      ORDER BY full_name;
    RETURN v_cur;
  END search_employees;

END pkg_employee;
/
CREATE OR REPLACE PACKAGE pkg_attendance AS
  PROCEDURE check_in(p_emp_id NUMBER);
  PROCEDURE check_out(p_emp_id NUMBER);
  PROCEDURE monthly_summary(p_emp_id NUMBER, p_month DATE,
                            p_days OUT NUMBER, p_hours OUT NUMBER,
                            p_overtime OUT NUMBER, p_leave_days OUT NUMBER);
  PROCEDURE attendance_report(p_month DATE);
END pkg_attendance;
/
CREATE OR REPLACE PACKAGE BODY pkg_attendance AS

  PROCEDURE check_in(p_emp_id NUMBER) IS
    v_status employees.status%TYPE;
  BEGIN
    SELECT status INTO v_status FROM employees WHERE emp_id = p_emp_id;
    IF v_status <> 'ACTIVE' THEN
      RAISE_APPLICATION_ERROR(-20010, 'Inactive employee cannot check in');
    END IF;
    INSERT INTO attendance(emp_id, att_date, in_time)
    VALUES (p_emp_id, TRUNC(SYSDATE), SYSTIMESTAMP);
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20011, 'Employee not found');
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(-20012, 'Already checked in today');
  END check_in;

  PROCEDURE check_out(p_emp_id NUMBER) IS
  BEGIN
    UPDATE attendance SET out_time = SYSTIMESTAMP
    WHERE  emp_id = p_emp_id AND att_date = TRUNC(SYSDATE) AND out_time IS NULL;
    IF SQL%ROWCOUNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20013, 'No open check-in found for today');
    END IF;
    COMMIT;
  END check_out;

  PROCEDURE monthly_summary(p_emp_id NUMBER, p_month DATE,
                            p_days OUT NUMBER, p_hours OUT NUMBER,
                            p_overtime OUT NUMBER, p_leave_days OUT NUMBER) IS
    v_start DATE := TRUNC(p_month, 'MM');
    v_end   DATE := LAST_DAY(TRUNC(p_month, 'MM'));
  BEGIN
    SELECT COUNT(*), NVL(SUM(work_hours), 0), NVL(SUM(overtime_hours), 0)
    INTO   p_days, p_hours, p_overtime
    FROM   attendance
    WHERE  emp_id = p_emp_id AND att_date BETWEEN v_start AND v_end;

    SELECT NVL(SUM(LEAST(leave_to, v_end) - GREATEST(leave_from, v_start) + 1), 0)
    INTO   p_leave_days
    FROM   leaves
    WHERE  emp_id = p_emp_id AND status = 'APPROVED'
    AND    leave_to >= v_start AND leave_from <= v_end;
  END monthly_summary;

  PROCEDURE attendance_report(p_month DATE) IS
    v_start DATE := TRUNC(p_month, 'MM');
    v_end   DATE := LAST_DAY(TRUNC(p_month, 'MM'));
  BEGIN
    DBMS_OUTPUT.PUT_LINE(RPAD('EMP', 6) || RPAD('NAME', 22) ||
                         RPAD('DAYS', 6) || RPAD('HOURS', 9) || 'OT');
    FOR rec IN (
      SELECT e.emp_id, e.first_name || ' ' || e.last_name AS emp_name,
             COUNT(a.att_id) AS days_present,
             NVL(SUM(a.work_hours), 0)     AS hrs,
             NVL(SUM(a.overtime_hours), 0) AS ot
      FROM   employees e
      LEFT   JOIN attendance a ON a.emp_id = e.emp_id
                              AND a.att_date BETWEEN v_start AND v_end
      WHERE  e.status = 'ACTIVE'
      GROUP  BY e.emp_id, e.first_name, e.last_name
      ORDER  BY e.emp_id)
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(rec.emp_id, 6) || RPAD(rec.emp_name, 22) ||
                           RPAD(rec.days_present, 6) || RPAD(rec.hrs, 9) || rec.ot);
    END LOOP;
  END attendance_report;

END pkg_attendance;
/
CREATE OR REPLACE PACKAGE pkg_payroll AS
  TYPE t_salary IS RECORD (
    basic NUMBER, hra NUMBER, da NUMBER, overtime_pay NUMBER, bonus NUMBER,
    absent_ded NUMBER, pf NUMBER, prof_tax NUMBER, adv_recovery NUMBER,
    gross NUMBER, total_ded NUMBER, net NUMBER);

  FUNCTION  get_working_days(p_month DATE) RETURN NUMBER;
  FUNCTION  calculate_salary(p_emp_id NUMBER, p_month DATE,
                             p_bonus NUMBER DEFAULT 0) RETURN t_salary;
  PROCEDURE generate_payroll(p_month DATE);
  PROCEDURE print_payslip(p_emp_id NUMBER, p_month DATE);
  PROCEDURE request_advance(p_emp_id NUMBER, p_amount NUMBER, p_installments NUMBER);
  PROCEDURE approve_advance(p_adv_id NUMBER, p_approver NUMBER, p_approve BOOLEAN);
END pkg_payroll;
/
CREATE OR REPLACE PACKAGE BODY pkg_payroll AS

  FUNCTION get_working_days(p_month DATE) RETURN NUMBER IS
    v_day DATE   := TRUNC(p_month, 'MM');
    v_end DATE   := LAST_DAY(v_day);
    v_cnt NUMBER := 0;
  BEGIN
    WHILE v_day <= v_end LOOP            -- Monday to Saturday are working days
      IF TO_CHAR(v_day, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') <> 'SUN' THEN
        v_cnt := v_cnt + 1;
      END IF;
      v_day := v_day + 1;
    END LOOP;
    RETURN v_cnt;
  END get_working_days;

  FUNCTION calculate_salary(p_emp_id NUMBER, p_month DATE,
                            p_bonus NUMBER DEFAULT 0) RETURN t_salary IS
    v_sal     t_salary;
    v_start   DATE := TRUNC(p_month, 'MM');
    v_end     DATE := LAST_DAY(TRUNC(p_month, 'MM'));
    v_workdays NUMBER := get_working_days(p_month);
    v_basic   employees.basic_salary%TYPE;
    v_present NUMBER;  v_ot NUMBER;  v_leave NUMBER;  v_absent NUMBER;
    v_daily   NUMBER;
  BEGIN
    SELECT basic_salary INTO v_basic
    FROM   employees WHERE emp_id = p_emp_id AND status = 'ACTIVE';

    SELECT COUNT(*), NVL(SUM(overtime_hours), 0) INTO v_present, v_ot
    FROM   attendance
    WHERE  emp_id = p_emp_id AND att_date BETWEEN v_start AND v_end;

    SELECT NVL(SUM(LEAST(leave_to, v_end) - GREATEST(leave_from, v_start) + 1), 0)
    INTO   v_leave
    FROM   leaves
    WHERE  emp_id = p_emp_id AND status = 'APPROVED'
    AND    leave_to >= v_start AND leave_from <= v_end;

    v_absent := GREATEST(v_workdays - v_present - v_leave, 0);
    v_daily  := v_basic / v_workdays;

    v_sal.basic        := v_basic;
    v_sal.hra          := ROUND(v_basic * 0.20, 2);
    v_sal.da           := ROUND(v_basic * 0.10, 2);
    v_sal.overtime_pay := ROUND(v_ot * (v_basic / (v_workdays * 8)) * 1.5, 2);
    v_sal.bonus        := NVL(p_bonus, 0);
    v_sal.absent_ded   := ROUND(v_absent * v_daily, 2);
    v_sal.pf           := ROUND(v_basic * 0.12, 2);
    v_sal.prof_tax     := 200;

    SELECT NVL(SUM(LEAST(monthly_recovery, balance)), 0) INTO v_sal.adv_recovery
    FROM   salary_advances
    WHERE  emp_id = p_emp_id AND status = 'APPROVED' AND balance > 0;

    v_sal.gross     := v_sal.basic + v_sal.hra + v_sal.da
                       + v_sal.overtime_pay + v_sal.bonus;
    v_sal.total_ded := v_sal.absent_ded + v_sal.pf + v_sal.prof_tax
                       + v_sal.adv_recovery;
    v_sal.net       := v_sal.gross - v_sal.total_ded;
    RETURN v_sal;
  END calculate_salary;

  PROCEDURE generate_payroll(p_month DATE) IS
    v_sal   t_salary;
    v_month DATE   := TRUNC(p_month, 'MM');
    v_done  NUMBER := 0;
    v_skip  NUMBER := 0;
  BEGIN
    FOR emp IN (SELECT emp_id FROM employees WHERE status = 'ACTIVE') LOOP
      BEGIN
        SAVEPOINT sp_emp;
        v_sal := calculate_salary(emp.emp_id, v_month);

        INSERT INTO payroll(emp_id, pay_month, basic, hra, da, overtime_pay,
                            bonus, deductions, net_salary)
        VALUES (emp.emp_id, v_month, v_sal.basic, v_sal.hra, v_sal.da,
                v_sal.overtime_pay, v_sal.bonus, v_sal.total_ded, v_sal.net);

        UPDATE salary_advances
        SET    balance = balance - LEAST(monthly_recovery, balance),
               status  = CASE WHEN balance - LEAST(monthly_recovery, balance) <= 0
                              THEN 'CLOSED' ELSE status END
        WHERE  emp_id = emp.emp_id AND status = 'APPROVED' AND balance > 0;
        v_done := v_done + 1;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN       -- payroll already generated for this month
          ROLLBACK TO sp_emp;
          v_skip := v_skip + 1;
      END;
    END LOOP;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Payroll generated: ' || v_done || ', skipped: ' || v_skip);
  END generate_payroll;

  PROCEDURE print_payslip(p_emp_id NUMBER, p_month DATE) IS
    v_p    payroll%ROWTYPE;
    v_name VARCHAR2(100);
    v_dept departments.dept_name%TYPE;
    FUNCTION f(n NUMBER) RETURN VARCHAR2 IS
    BEGIN RETURN LPAD(TO_CHAR(n, 'FM9,999,990.00'), 12); END;
  BEGIN
    SELECT * INTO v_p FROM payroll
    WHERE  emp_id = p_emp_id AND pay_month = TRUNC(p_month, 'MM');
    SELECT e.first_name || ' ' || e.last_name, d.dept_name INTO v_name, v_dept
    FROM   employees e JOIN departments d ON d.dept_id = e.dept_id
    WHERE  e.emp_id = p_emp_id;

    DBMS_OUTPUT.PUT_LINE('PAYSLIP FOR ' || TO_CHAR(v_p.pay_month, 'MON-YYYY'));
    DBMS_OUTPUT.PUT_LINE('Employee : ' || v_name || ' (' || v_dept || ')');
    DBMS_OUTPUT.PUT_LINE('Basic            ' || f(v_p.basic));
    DBMS_OUTPUT.PUT_LINE('HRA              ' || f(v_p.hra));
    DBMS_OUTPUT.PUT_LINE('DA               ' || f(v_p.da));
    DBMS_OUTPUT.PUT_LINE('Overtime pay     ' || f(v_p.overtime_pay));
    DBMS_OUTPUT.PUT_LINE('Bonus            ' || f(v_p.bonus));
    DBMS_OUTPUT.PUT_LINE('Total deductions ' || f(v_p.deductions));
    DBMS_OUTPUT.PUT_LINE('NET SALARY       ' || f(v_p.net_salary));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20020, 'Payroll not generated for this employee/month');
  END print_payslip;

  PROCEDURE request_advance(p_emp_id NUMBER, p_amount NUMBER, p_installments NUMBER) IS
    v_basic employees.basic_salary%TYPE;
    v_open  NUMBER;
  BEGIN
    SELECT basic_salary INTO v_basic
    FROM   employees WHERE emp_id = p_emp_id AND status = 'ACTIVE';
    IF p_amount <= 0 OR p_installments < 1 THEN
      RAISE_APPLICATION_ERROR(-20030, 'Invalid amount or number of installments');
    END IF;
    IF p_amount > 2 * v_basic THEN
      RAISE_APPLICATION_ERROR(-20031, 'Advance cannot exceed two months basic salary');
    END IF;
    SELECT COUNT(*) INTO v_open FROM salary_advances
    WHERE  emp_id = p_emp_id AND status IN ('PENDING', 'APPROVED');
    IF v_open > 0 THEN
      RAISE_APPLICATION_ERROR(-20032, 'An earlier advance is still open');
    END IF;
    INSERT INTO salary_advances(emp_id, amount, balance, monthly_recovery)
    VALUES (p_emp_id, p_amount, p_amount, ROUND(p_amount / p_installments, 2));
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20033, 'Active employee not found');
  END request_advance;

  PROCEDURE approve_advance(p_adv_id NUMBER, p_approver NUMBER, p_approve BOOLEAN) IS
    v_status salary_advances.status%TYPE;
    v_new    salary_advances.status%TYPE;
    e_locked EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_locked, -54);
  BEGIN
    SELECT status INTO v_status FROM salary_advances
    WHERE  adv_id = p_adv_id FOR UPDATE NOWAIT;      -- row lock against double approval
    IF v_status <> 'PENDING' THEN
      RAISE_APPLICATION_ERROR(-20034, 'Request has already been processed');
    END IF;
    v_new := CASE WHEN p_approve THEN 'APPROVED' ELSE 'REJECTED' END;
    UPDATE salary_advances
    SET    status = v_new, approved_by = p_approver, decided_on = SYSDATE
    WHERE  adv_id = p_adv_id;
    COMMIT;
  EXCEPTION
    WHEN e_locked THEN
      RAISE_APPLICATION_ERROR(-20035, 'Request is being processed by another user');
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20036, 'Advance request not found');
  END approve_advance;

END pkg_payroll;
/
CREATE OR REPLACE PACKAGE pkg_performance AS
  PROCEDURE record_review(p_emp_id NUMBER, p_reviewer_id NUMBER,
                          p_period VARCHAR2, p_rating NUMBER, p_feedback VARCHAR2);
  PROCEDURE performance_report(p_period VARCHAR2);
  FUNCTION  promotion_eligible(p_emp_id NUMBER) RETURN BOOLEAN;
END pkg_performance;
/
CREATE OR REPLACE PACKAGE BODY pkg_performance AS

  PROCEDURE record_review(p_emp_id NUMBER, p_reviewer_id NUMBER,
                          p_period VARCHAR2, p_rating NUMBER, p_feedback VARCHAR2) IS
  BEGIN
    INSERT INTO performance_reviews(emp_id, reviewer_id, review_period, rating, feedback)
    VALUES (p_emp_id, p_reviewer_id, p_period, p_rating, p_feedback);
    COMMIT;
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(-20040, 'Review already recorded for this period');
  END record_review;

  PROCEDURE performance_report(p_period VARCHAR2) IS
    CURSOR c_rank IS
      SELECT d.dept_name, e.first_name || ' ' || e.last_name AS emp_name,
             ROUND(AVG(r.rating), 2) AS avg_rating,
             RANK() OVER (PARTITION BY e.dept_id
                          ORDER BY AVG(r.rating) DESC) AS dept_rank
      FROM   performance_reviews r
      JOIN   employees   e ON e.emp_id  = r.emp_id
      JOIN   departments d ON d.dept_id = e.dept_id
      WHERE  r.review_period = p_period
      GROUP  BY d.dept_name, e.dept_id, e.emp_id, e.first_name, e.last_name
      ORDER  BY d.dept_name, dept_rank;
  BEGIN
    FOR rec IN c_rank LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(rec.dept_name, 14) || RPAD(rec.emp_name, 22) ||
                           RPAD(rec.avg_rating, 8) || '#' || rec.dept_rank);
    END LOOP;
  END performance_report;

  FUNCTION promotion_eligible(p_emp_id NUMBER) RETURN BOOLEAN IS
    v_avg NUMBER;
  BEGIN
    SELECT AVG(rating) INTO v_avg
    FROM  (SELECT rating FROM performance_reviews
           WHERE  emp_id = p_emp_id
           ORDER  BY review_date DESC
           FETCH FIRST 2 ROWS ONLY);
    RETURN NVL(v_avg, 0) >= 4.5;
  END promotion_eligible;

END pkg_performance;
/
CREATE OR REPLACE PACKAGE pkg_security AS
  PROCEDURE register_user(p_emp_id NUMBER, p_username VARCHAR2,
                          p_password VARCHAR2, p_role_id NUMBER);
  FUNCTION  authenticate(p_username VARCHAR2, p_password VARCHAR2) RETURN VARCHAR2;
END pkg_security;
/
CREATE OR REPLACE PACKAGE BODY pkg_security AS

  FUNCTION hash_pwd(p_salt VARCHAR2, p_pwd VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN RAWTOHEX(STANDARD_HASH(p_salt || p_pwd, 'SHA256'));
  END hash_pwd;

  PROCEDURE register_user(p_emp_id NUMBER, p_username VARCHAR2,
                          p_password VARCHAR2, p_role_id NUMBER) IS
    v_salt VARCHAR2(32) := RAWTOHEX(SYS_GUID());
  BEGIN
    INSERT INTO users_auth(emp_id, role_id, username, salt, pwd_hash)
    VALUES (p_emp_id, p_role_id, LOWER(p_username), v_salt, hash_pwd(v_salt, p_password));
    COMMIT;
  END register_user;

  -- returns the role name on success, otherwise DENIED or LOCKED
  FUNCTION authenticate(p_username VARCHAR2, p_password VARCHAR2) RETURN VARCHAR2 IS
    v_rec  users_auth%ROWTYPE;
    v_role roles.role_name%TYPE;
  BEGIN
    SELECT * INTO v_rec FROM users_auth WHERE username = LOWER(p_username);
    IF v_rec.failed_attempts >= 5 THEN
      RETURN 'LOCKED';
    END IF;
    IF v_rec.pwd_hash = hash_pwd(v_rec.salt, p_password) THEN
      UPDATE users_auth SET failed_attempts = 0, last_login = SYSTIMESTAMP
      WHERE  user_id = v_rec.user_id;
      SELECT role_name INTO v_role FROM roles WHERE role_id = v_rec.role_id;
      COMMIT;
      RETURN v_role;
    ELSE
      UPDATE users_auth SET failed_attempts = failed_attempts + 1
      WHERE  user_id = v_rec.user_id;
      COMMIT;
      RETURN 'DENIED';
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 'DENIED';
  END authenticate;

END pkg_security;
/

-- Roles and privileges (run as the schema owner / DBA)
CREATE ROLE hr_role;
CREATE ROLE manager_role;
CREATE ROLE employee_role;
GRANT EXECUTE ON pkg_employee    TO hr_role;
GRANT EXECUTE ON pkg_payroll     TO hr_role;
GRANT EXECUTE ON pkg_performance TO hr_role, manager_role;
GRANT EXECUTE ON pkg_attendance  TO hr_role, employee_role;
GRANT SELECT  ON v_employee_details TO hr_role, manager_role, employee_role;
GRANT SELECT  ON mv_dept_payroll    TO hr_role;
-- Console "screens" of the application, written entirely in PL/SQL.
CREATE OR REPLACE PACKAGE pkg_ems_ui AS
  PROCEDURE show_employees(p_name VARCHAR2 DEFAULT NULL);
  PROCEDURE show_dashboard;
  PROCEDURE show_payroll(p_month DATE);
  PROCEDURE show_audit(p_rows NUMBER DEFAULT 20);
END pkg_ems_ui;
/
CREATE OR REPLACE PACKAGE BODY pkg_ems_ui AS

  PROCEDURE hr_line IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 78, '-'));
  END hr_line;

  FUNCTION money(n NUMBER) RETURN VARCHAR2 IS
  BEGIN
    RETURN LPAD(TO_CHAR(NVL(n, 0), 'FM999,999,990.00'), 12);
  END money;

  PROCEDURE show_employees(p_name VARCHAR2 DEFAULT NULL) IS
    c      SYS_REFCURSOR;
    v_id   NUMBER;
    v_name VARCHAR2(100);
    v_mail VARCHAR2(80);
    v_dept VARCHAR2(50);
    v_des  VARCHAR2(50);
    v_cnt  NUMBER := 0;
  BEGIN
    DBMS_OUTPUT.PUT_LINE('EMPLOYEES' || CASE WHEN p_name IS NOT NULL
                         THEN ' matching "' || p_name || '"' END);
    hr_line;
    DBMS_OUTPUT.PUT_LINE(RPAD('ID', 5) || RPAD('NAME', 20) || RPAD('EMAIL', 30) ||
                         RPAD('DEPARTMENT', 17) || 'DESIGNATION');
    hr_line;
    c := pkg_employee.search_employees(p_name);
    LOOP
      FETCH c INTO v_id, v_name, v_mail, v_dept, v_des;
      EXIT WHEN c%NOTFOUND;
      v_cnt := v_cnt + 1;
      DBMS_OUTPUT.PUT_LINE(RPAD(v_id, 5) || RPAD(v_name, 20) || RPAD(v_mail, 30) ||
                           RPAD(v_dept, 17) || v_des);
    END LOOP;
    CLOSE c;
    hr_line;
    DBMS_OUTPUT.PUT_LINE(v_cnt || ' employee(s) found.');
  END show_employees;

  PROCEDURE show_dashboard IS
    v_emp NUMBER;  v_leave NUMBER;  v_adv NUMBER;  v_rating NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_emp   FROM employees WHERE status = 'ACTIVE';
    SELECT COUNT(*) INTO v_leave FROM leaves WHERE status = 'PENDING';
    SELECT COUNT(*) INTO v_adv   FROM salary_advances WHERE status = 'PENDING';
    SELECT NVL(ROUND(AVG(rating), 2), 0) INTO v_rating FROM performance_reviews;
    DBMS_OUTPUT.PUT_LINE('DASHBOARD');
    hr_line;
    DBMS_OUTPUT.PUT_LINE('Active employees        : ' || v_emp);
    DBMS_OUTPUT.PUT_LINE('Pending leave requests  : ' || v_leave);
    DBMS_OUTPUT.PUT_LINE('Pending salary advances : ' || v_adv);
    DBMS_OUTPUT.PUT_LINE('Average rating          : ' || v_rating);
    hr_line;
    DBMS_OUTPUT.PUT_LINE(RPAD('DEPARTMENT', 20) || RPAD('HEADCOUNT', 11) || 'MONTHLY BASIC');
    FOR r IN (SELECT d.dept_name, COUNT(e.emp_id) AS cnt,
                     NVL(SUM(e.basic_salary), 0) AS tot
              FROM   departments d
              LEFT   JOIN employees e ON e.dept_id = d.dept_id AND e.status = 'ACTIVE'
              GROUP  BY d.dept_name ORDER BY d.dept_name)
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(r.dept_name, 20) || RPAD(r.cnt, 11) || money(r.tot));
    END LOOP;
    hr_line;
    DBMS_OUTPUT.PUT_LINE('Net payroll by month');
    FOR r IN (SELECT pay_month, SUM(net_salary) AS tot FROM payroll
              GROUP BY pay_month ORDER BY pay_month)
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(TO_CHAR(r.pay_month, 'MON-YYYY'), 20) || RPAD(' ', 11) || money(r.tot));
    END LOOP;
  END show_dashboard;

  PROCEDURE show_payroll(p_month DATE) IS
    v_total NUMBER := 0;
  BEGIN
    DBMS_OUTPUT.PUT_LINE('PAYROLL REGISTER ' || TO_CHAR(p_month, 'MON-YYYY'));
    hr_line;
    DBMS_OUTPUT.PUT_LINE(RPAD('ID', 4) || RPAD('NAME', 18) || LPAD('BASIC', 11) ||
                         LPAD('OVERTIME', 11) || LPAD('DEDUCTION', 12) || LPAD('NET', 13));
    hr_line;
    FOR r IN (SELECT e.emp_id, e.first_name || ' ' || e.last_name AS nm, p.basic,
                     p.overtime_pay, p.deductions, p.net_salary
              FROM   payroll p JOIN employees e ON e.emp_id = p.emp_id
              WHERE  p.pay_month = TRUNC(p_month, 'MM') ORDER BY e.emp_id)
    LOOP
      v_total := v_total + r.net_salary;
      DBMS_OUTPUT.PUT_LINE(RPAD(r.emp_id, 4) || RPAD(r.nm, 18) || LPAD(TO_CHAR(r.basic, 'FM9,99,990'), 11)
                           || LPAD(TO_CHAR(r.overtime_pay, 'FM99,990.00'), 11)
                           || LPAD(TO_CHAR(r.deductions, 'FM99,990.00'), 12)
                           || LPAD(TO_CHAR(r.net_salary, 'FM9,99,990.00'), 13));
    END LOOP;
    hr_line;
    DBMS_OUTPUT.PUT_LINE('Total net payout: ' || TO_CHAR(v_total, 'FM9,99,99,990.00'));
  END show_payroll;

  PROCEDURE show_audit(p_rows NUMBER DEFAULT 20) IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE('AUDIT LOG (latest ' || p_rows || ')');
    hr_line;
    FOR r IN (SELECT log_id, operation, key_value, new_value, changed_by,
                     TO_CHAR(changed_on, 'DD-MON-YY HH24:MI') AS ts
              FROM   audit_log ORDER BY log_id DESC FETCH FIRST p_rows ROWS ONLY)
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(r.log_id, 5) || RPAD(r.operation, 8) || RPAD(r.key_value, 5) ||
                           RPAD(r.ts, 17) || r.new_value);
    END LOOP;
  END show_audit;

END pkg_ems_ui;
/
-- Complete automatic demonstration written in PL/SQL.
-- Seeds master data, simulates a month of attendance, runs payroll, advances,
-- reviews, security and audit, and prints every result with DBMS_OUTPUT.
SET SERVEROUTPUT ON SIZE UNLIMITED
SET VERIFY OFF

PROMPT ===== STEP 1: Master data =====
BEGIN
  INSERT INTO departments(dept_name, location) VALUES ('IT', 'Ludhiana');
  INSERT INTO departments(dept_name, location) VALUES ('Human Resources', 'Ludhiana');
  INSERT INTO departments(dept_name, location) VALUES ('Finance', 'Chandigarh');
  INSERT INTO designations(title, min_salary, max_salary) VALUES ('Software Engineer', 30000, 90000);
  INSERT INTO designations(title, min_salary, max_salary) VALUES ('HR Executive', 25000, 60000);
  INSERT INTO designations(title, min_salary, max_salary) VALUES ('Accountant', 25000, 70000);
  INSERT INTO designations(title, min_salary, max_salary) VALUES ('Manager', 60000, 150000);
  INSERT INTO roles(role_name) VALUES ('HR');
  INSERT INTO roles(role_name) VALUES ('MANAGER');
  INSERT INTO roles(role_name) VALUES ('EMPLOYEE');
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('3 departments, 4 designations and 3 roles inserted.');
END;
/

PROMPT ===== STEP 2: Add employees (pkg_employee.add_employee) =====
DECLARE
  v_id  NUMBER;
  v_mgr NUMBER;
  PROCEDURE hire(p_f VARCHAR2, p_l VARCHAR2, p_dept NUMBER, p_des NUMBER,
                 p_sal NUMBER, p_manager NUMBER) IS
  BEGIN
    pkg_employee.add_employee(p_f, p_l, p_f || '.' || p_l || '@example.com',
                              '98765' || LPAD(TRUNC(DBMS_RANDOM.VALUE(0, 99999)), 5, '0'),
                              p_dept, p_des, p_manager, p_sal, v_id);
    DBMS_OUTPUT.PUT_LINE('Added employee ' || v_id || ': ' || INITCAP(p_f) || ' ' || INITCAP(p_l));
  END hire;
BEGIN
  hire('rajesh',   'verma',  1, 4, 110000, NULL);
  v_mgr := v_id;
  hire('amit',     'sharma', 1, 1,  65000, v_mgr);
  hire('neha',     'kapoor', 2, 2,  42000, v_mgr);
  hire('simran',   'kaur',   3, 3,  48000, v_mgr);
  hire('harpreet', 'singh',  1, 1,  72000, v_mgr);
  hire('jaspal',   'gill',   3, 3,  39000, v_mgr);
END;
/

PROMPT ===== STEP 3: Business-rule check (salary above designation maximum) =====
DECLARE
  v_id NUMBER;
BEGIN
  pkg_employee.add_employee('Test', 'User', 'test.user@example.com', NULL, 1, 1, 1, 200000, v_id);
EXCEPTION
  WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Rejected as expected -> ' || SQLERRM);
END;
/

PROMPT ===== STEP 4: Simulate attendance for September 2026 (trigger computes hours) =====
DECLARE
  v_start DATE := DATE '2026-09-01';
  v_day   DATE;
  v_hours NUMBER;
  v_rows  NUMBER := 0;
BEGIN
  FOR e IN (SELECT emp_id FROM employees WHERE status = 'ACTIVE') LOOP
    FOR i IN 0 .. 29 LOOP
      v_day := v_start + i;
      IF TO_CHAR(v_day, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') <> 'SUN'
         AND MOD(i + e.emp_id, 11) <> 0 THEN           -- an occasional absence
        v_hours := 7.5 + MOD(i * e.emp_id, 4) * 0.5;    -- 7.5 to 9.0 hours
        INSERT INTO attendance(emp_id, att_date, in_time, out_time)
        VALUES (e.emp_id, v_day,
                CAST(v_day + 9/24 AS TIMESTAMP),
                CAST(v_day + 9/24 + v_hours/24 AS TIMESTAMP));
        v_rows := v_rows + 1;
      END IF;
    END LOOP;
  END LOOP;
  INSERT INTO leaves(emp_id, leave_type, leave_from, leave_to, status)
  VALUES (2, 'SICK', DATE '2026-09-02', DATE '2026-09-02', 'APPROVED');
  COMMIT;
  DBMS_OUTPUT.PUT_LINE(v_rows || ' attendance rows inserted; 1 approved leave for employee 2.');
END;
/

PROMPT ===== STEP 5: Monthly attendance summary and report =====
DECLARE
  v_days NUMBER; v_hrs NUMBER; v_ot NUMBER; v_lv NUMBER;
BEGIN
  pkg_attendance.monthly_summary(2, DATE '2026-09-01', v_days, v_hrs, v_ot, v_lv);
  DBMS_OUTPUT.PUT_LINE('Employee 2 -> days: ' || v_days || ', hours: ' || v_hrs ||
                       ', overtime: ' || v_ot || ', leave days: ' || v_lv);
  DBMS_OUTPUT.PUT_LINE(' ');
  pkg_attendance.attendance_report(DATE '2026-09-01');
END;
/

PROMPT ===== STEP 6: Generate payroll (run twice to prove it is idempotent) =====
BEGIN
  pkg_payroll.generate_payroll(DATE '2026-09-01');
  pkg_payroll.generate_payroll(DATE '2026-09-01');
END;
/
BEGIN
  pkg_ems_ui.show_payroll(DATE '2026-09-01');
  DBMS_OUTPUT.PUT_LINE(' ');
  pkg_payroll.print_payslip(2, DATE '2026-09-01');
END;
/

PROMPT ===== STEP 7: Salary advance workflow =====
DECLARE
  v_sal pkg_payroll.t_salary;
BEGIN
  pkg_payroll.request_advance(2, 50000, 5);
  DBMS_OUTPUT.PUT_LINE('Advance requested by employee 2.');
  BEGIN
    pkg_payroll.request_advance(2, 10000, 2);
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Second request rejected -> ' || SQLERRM);
  END;
  pkg_payroll.approve_advance(1, 1, TRUE);
  DBMS_OUTPUT.PUT_LINE('Advance approved by manager (employee 1).');
  BEGIN
    pkg_payroll.approve_advance(1, 1, TRUE);
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Double approval rejected -> ' || SQLERRM);
  END;
  v_sal := pkg_payroll.calculate_salary(2, DATE '2026-10-01');
  DBMS_OUTPUT.PUT_LINE('October advance recovery for employee 2: ' || v_sal.adv_recovery);
END;
/

PROMPT ===== STEP 8: Performance reviews and ranking =====
BEGIN
  pkg_performance.record_review(2, 1, '2026-H1', 4.6, 'Excellent delivery');
  pkg_performance.record_review(5, 1, '2026-H1', 4.2, 'Consistent');
  pkg_performance.record_review(3, 1, '2026-H1', 4.4, 'Strong team player');
  pkg_performance.record_review(4, 1, '2026-H1', 4.1, 'Accurate and timely');
  pkg_performance.record_review(6, 1, '2026-H1', 3.8, 'Needs improvement in reports');
  pkg_performance.performance_report('2026-H1');
  DBMS_OUTPUT.PUT_LINE('Employee 2 promotion eligible: ' ||
    CASE WHEN pkg_performance.promotion_eligible(2) THEN 'YES' ELSE 'NO' END);
END;
/

PROMPT ===== STEP 9: Security - registration, login and lockout =====
DECLARE
  v_res VARCHAR2(20);
BEGIN
  pkg_security.register_user(1, 'rajesh', 'Secret#123', 1);
  pkg_security.register_user(2, 'amit',   'Welcome@45', 3);
  DBMS_OUTPUT.PUT_LINE('amit / correct password -> ' || pkg_security.authenticate('amit', 'Welcome@45'));
  DBMS_OUTPUT.PUT_LINE('amit / wrong password   -> ' || pkg_security.authenticate('amit', 'wrong'));
  FOR i IN 1 .. 4 LOOP
    v_res := pkg_security.authenticate('amit', 'wrong');
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('after 5 failures, correct password -> ' || pkg_security.authenticate('amit', 'Welcome@45'));
END;
/

PROMPT ===== STEP 10: Update, soft delete and audit trail =====
BEGIN
  pkg_employee.update_employee(5, p_salary => 78000);
  pkg_employee.remove_employee(6);
  BEGIN
    DELETE FROM employees WHERE emp_id = 1;
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Physical delete blocked -> ' || SQLERRM);
  END;
  ROLLBACK;
  pkg_ems_ui.show_audit(8);
END;
/

PROMPT ===== STEP 11: Dashboard =====
BEGIN
  pkg_ems_ui.show_dashboard;
  pkg_ems_ui.show_employees;
END;
/
PROMPT ===== DEMO COMPLETE =====
