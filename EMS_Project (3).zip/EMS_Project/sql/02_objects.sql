-- Indexes
CREATE INDEX idx_emp_dept   ON employees(dept_id);
CREATE INDEX idx_emp_desig  ON employees(desig_id);
CREATE INDEX idx_emp_lname  ON employees(UPPER(last_name));
CREATE INDEX idx_leave_emp  ON leaves(emp_id, leave_from, leave_to);
CREATE INDEX idx_pay_month  ON payroll(pay_month);

-- View hiding salary and other sensitive columns
CREATE OR REPLACE VIEW v_employee_details AS
SELECT e.emp_id,
       e.first_name || ' ' || e.last_name AS full_name,
       e.email, e.phone, d.dept_name,
       g.title AS designation, e.hire_date, e.status
FROM   employees e
JOIN   departments d  ON d.dept_id  = e.dept_id
JOIN   designations g ON g.desig_id = e.desig_id;

-- Materialized view for department-wise payroll analysis
CREATE MATERIALIZED VIEW mv_dept_payroll
BUILD IMMEDIATE REFRESH COMPLETE ON DEMAND AS
SELECT e.dept_id, p.pay_month,
       COUNT(*)          AS headcount,
       SUM(p.net_salary) AS total_net
FROM   payroll p JOIN employees e ON e.emp_id = p.emp_id
GROUP  BY e.dept_id, p.pay_month;
