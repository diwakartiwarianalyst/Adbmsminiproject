SET SERVEROUTPUT ON
VARIABLE id NUMBER

INSERT INTO departments(dept_name, location) VALUES ('IT', 'Ludhiana');
INSERT INTO departments(dept_name, location) VALUES ('Human Resources', 'Ludhiana');
INSERT INTO departments(dept_name, location) VALUES ('Finance', 'Chandigarh');
INSERT INTO designations(title, min_salary, max_salary) VALUES ('Software Engineer', 30000, 90000);
INSERT INTO designations(title, min_salary, max_salary) VALUES ('HR Executive', 25000, 60000);
INSERT INTO designations(title, min_salary, max_salary) VALUES ('Accountant', 25000, 70000);
INSERT INTO designations(title, min_salary, max_salary) VALUES ('Manager', 60000, 150000);
INSERT INTO roles(role_name) VALUES ('HR');
INSERT INTO roles(role_name) VALUES ('MANAGER');
INSERT INTO roles(role_name) VALUES ('EMPLOYEE');
COMMIT;

DECLARE
  v_id  NUMBER;
  v_mgr NUMBER;
BEGIN
  pkg_employee.add_employee('rajesh','verma','rajesh.verma@example.com','9876500001',
                            1, 4, NULL, 110000, v_mgr);
  pkg_employee.add_employee('amit','sharma','amit.sharma@example.com','9876500002',
                            1, 1, v_mgr, 65000, v_id);
  pkg_employee.add_employee('neha','kapoor','neha.kapoor@example.com','9876500003',
                            2, 2, v_mgr, 42000, v_id);
  pkg_employee.add_employee('simran','kaur','simran.kaur@example.com','9876500004',
                            3, 3, v_mgr, 48000, v_id);
END;
/

-- Test 1: salary outside the designation range must be rejected
EXEC pkg_employee.add_employee('Test','User','t@example.com',NULL,1,1,NULL,200000,:id);

-- Test 2: attendance and payroll
EXEC pkg_attendance.check_in(2);
EXEC pkg_attendance.check_out(2);
EXEC pkg_payroll.generate_payroll(DATE '2026-09-01');
EXEC pkg_payroll.print_payslip(2, DATE '2026-09-01');

-- Test 3: salary advance workflow
EXEC pkg_payroll.request_advance(2, 50000, 5);
EXEC pkg_payroll.approve_advance(1, 1, TRUE);

-- Test 4: performance ranking
EXEC pkg_performance.record_review(2, 1, '2026-H1', 4.6, 'Excellent delivery');
EXEC pkg_performance.performance_report('2026-H1');
