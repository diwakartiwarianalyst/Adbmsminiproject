-- Computes working hours and overtime when an employee checks out
CREATE OR REPLACE TRIGGER trg_att_hours
BEFORE INSERT OR UPDATE OF out_time ON attendance
FOR EACH ROW
WHEN (NEW.out_time IS NOT NULL)
DECLARE
  v_hours NUMBER;
BEGIN
  v_hours := ROUND(
      EXTRACT(DAY    FROM (:NEW.out_time - :NEW.in_time)) * 24
    + EXTRACT(HOUR   FROM (:NEW.out_time - :NEW.in_time))
    + EXTRACT(MINUTE FROM (:NEW.out_time - :NEW.in_time)) / 60, 2);
  :NEW.work_hours     := v_hours;
  :NEW.overtime_hours := GREATEST(v_hours - 8, 0);
END trg_att_hours;
/

-- Audit trail for employee inserts and updates
CREATE OR REPLACE TRIGGER trg_emp_audit
AFTER INSERT OR UPDATE ON employees
FOR EACH ROW
DECLARE
  v_op  VARCHAR2(10);
  v_old VARCHAR2(400);
  v_new VARCHAR2(400);
BEGIN
  IF INSERTING THEN
    v_op  := 'INSERT';
  ELSE
    v_op  := 'UPDATE';
    v_old := 'dept=' || :OLD.dept_id || ';desig=' || :OLD.desig_id
             || ';salary=' || :OLD.basic_salary || ';status=' || :OLD.status;
  END IF;
  v_new := 'dept=' || :NEW.dept_id || ';desig=' || :NEW.desig_id
           || ';salary=' || :NEW.basic_salary || ';status=' || :NEW.status;
  INSERT INTO audit_log(table_name, operation, key_value, old_value, new_value, changed_by)
  VALUES ('EMPLOYEES', v_op, :NEW.emp_id, v_old, v_new,
          SYS_CONTEXT('USERENV', 'SESSION_USER'));
END trg_emp_audit;
/

-- Physical deletion is blocked: employees are retired by setting status = INACTIVE
CREATE OR REPLACE TRIGGER trg_emp_no_delete
BEFORE DELETE ON employees
BEGIN
  RAISE_APPLICATION_ERROR(-20099,
    'Employees cannot be deleted. Use pkg_employee.remove_employee.');
END trg_emp_no_delete;
/
