CREATE OR REPLACE PACKAGE pkg_attendance AS
  PROCEDURE check_in(p_emp_id NUMBER);
  PROCEDURE check_out(p_emp_id NUMBER);
  PROCEDURE monthly_summary(p_emp_id NUMBER, p_month DATE,
                            p_days OUT NUMBER, p_hours OUT NUMBER,
                            p_overtime OUT NUMBER, p_leave_days OUT NUMBER);
  PROCEDURE attendance_report(p_month DATE);
END pkg_attendance;
/
CREATE OR REPLACE PACKAGE BODY pkg_attendance AS

  PROCEDURE check_in(p_emp_id NUMBER) IS
    v_status employees.status%TYPE;
  BEGIN
    SELECT status INTO v_status FROM employees WHERE emp_id = p_emp_id;
    IF v_status <> 'ACTIVE' THEN
      RAISE_APPLICATION_ERROR(-20010, 'Inactive employee cannot check in');
    END IF;
    INSERT INTO attendance(emp_id, att_date, in_time)
    VALUES (p_emp_id, TRUNC(SYSDATE), SYSTIMESTAMP);
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20011, 'Employee not found');
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(-20012, 'Already checked in today');
  END check_in;

  PROCEDURE check_out(p_emp_id NUMBER) IS
  BEGIN
    UPDATE attendance SET out_time = SYSTIMESTAMP
    WHERE  emp_id = p_emp_id AND att_date = TRUNC(SYSDATE) AND out_time IS NULL;
    IF SQL%ROWCOUNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20013, 'No open check-in found for today');
    END IF;
    COMMIT;
  END check_out;

  PROCEDURE monthly_summary(p_emp_id NUMBER, p_month DATE,
                            p_days OUT NUMBER, p_hours OUT NUMBER,
                            p_overtime OUT NUMBER, p_leave_days OUT NUMBER) IS
    v_start DATE := TRUNC(p_month, 'MM');
    v_end   DATE := LAST_DAY(TRUNC(p_month, 'MM'));
  BEGIN
    SELECT COUNT(*), NVL(SUM(work_hours), 0), NVL(SUM(overtime_hours), 0)
    INTO   p_days, p_hours, p_overtime
    FROM   attendance
    WHERE  emp_id = p_emp_id AND att_date BETWEEN v_start AND v_end;

    SELECT NVL(SUM(LEAST(leave_to, v_end) - GREATEST(leave_from, v_start) + 1), 0)
    INTO   p_leave_days
    FROM   leaves
    WHERE  emp_id = p_emp_id AND status = 'APPROVED'
    AND    leave_to >= v_start AND leave_from <= v_end;
  END monthly_summary;

  PROCEDURE attendance_report(p_month DATE) IS
    v_start DATE := TRUNC(p_month, 'MM');
    v_end   DATE := LAST_DAY(TRUNC(p_month, 'MM'));
  BEGIN
    DBMS_OUTPUT.PUT_LINE(RPAD('EMP', 6) || RPAD('NAME', 22) ||
                         RPAD('DAYS', 6) || RPAD('HOURS', 9) || 'OT');
    FOR rec IN (
      SELECT e.emp_id, e.first_name || ' ' || e.last_name AS emp_name,
             COUNT(a.att_id) AS days_present,
             NVL(SUM(a.work_hours), 0)     AS hrs,
             NVL(SUM(a.overtime_hours), 0) AS ot
      FROM   employees e
      LEFT   JOIN attendance a ON a.emp_id = e.emp_id
                              AND a.att_date BETWEEN v_start AND v_end
      WHERE  e.status = 'ACTIVE'
      GROUP  BY e.emp_id, e.first_name, e.last_name
      ORDER  BY e.emp_id)
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(rec.emp_id, 6) || RPAD(rec.emp_name, 22) ||
                           RPAD(rec.days_present, 6) || RPAD(rec.hrs, 9) || rec.ot);
    END LOOP;
  END attendance_report;

END pkg_attendance;
/
