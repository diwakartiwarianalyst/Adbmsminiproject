-- Removes every EMS object from the CURRENT schema so the project can be re-run.
-- Safe to run when nothing exists (errors are ignored).
SET SERVEROUTPUT ON
BEGIN
  FOR r IN (SELECT object_name, object_type FROM user_objects
            WHERE  object_type IN ('PACKAGE','VIEW','MATERIALIZED VIEW'))
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP ' || r.object_type || ' ' || r.object_name;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
  FOR r IN (SELECT table_name FROM user_tables
            WHERE  table_name IN ('AUDIT_LOG','PERFORMANCE_REVIEWS','SALARY_ADVANCES',
                                  'PAYROLL','LEAVES','ATTENDANCE','USERS_AUTH','ROLES',
                                  'EMPLOYEES','DESIGNATIONS','DEPARTMENTS'))
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE ' || r.table_name || ' CASCADE CONSTRAINTS PURGE';
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('Cleanup finished.');
END;
/
