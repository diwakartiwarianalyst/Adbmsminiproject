CREATE OR REPLACE PACKAGE pkg_employee AS
  PROCEDURE add_employee(p_first VARCHAR2, p_last VARCHAR2, p_email VARCHAR2,
                         p_phone VARCHAR2, p_dept_id NUMBER, p_desig_id NUMBER,
                         p_manager_id NUMBER, p_salary NUMBER, p_emp_id OUT NUMBER);
  PROCEDURE update_employee(p_emp_id NUMBER, p_phone VARCHAR2 DEFAULT NULL,
                            p_dept_id NUMBER DEFAULT NULL,
                            p_desig_id NUMBER DEFAULT NULL,
                            p_salary NUMBER DEFAULT NULL);
  PROCEDURE remove_employee(p_emp_id NUMBER);
  FUNCTION search_employees(p_name VARCHAR2 DEFAULT NULL,
                            p_dept_id NUMBER DEFAULT NULL,
                            p_desig_id NUMBER DEFAULT NULL) RETURN SYS_REFCURSOR;
END pkg_employee;
/
CREATE OR REPLACE PACKAGE BODY pkg_employee AS

  PROCEDURE add_employee(p_first VARCHAR2, p_last VARCHAR2, p_email VARCHAR2,
                         p_phone VARCHAR2, p_dept_id NUMBER, p_desig_id NUMBER,
                         p_manager_id NUMBER, p_salary NUMBER, p_emp_id OUT NUMBER) IS
    v_min designations.min_salary%TYPE;
    v_max designations.max_salary%TYPE;
  BEGIN
    SELECT min_salary, max_salary INTO v_min, v_max
    FROM   designations WHERE desig_id = p_desig_id;

    IF p_salary NOT BETWEEN v_min AND v_max THEN
      RAISE_APPLICATION_ERROR(-20001, 'Salary is outside the range for this designation');
    END IF;

    INSERT INTO employees(first_name, last_name, email, phone, dept_id,
                          desig_id, manager_id, basic_salary)
    VALUES (INITCAP(p_first), INITCAP(p_last), LOWER(p_email), p_phone,
            p_dept_id, p_desig_id, p_manager_id, p_salary)
    RETURNING emp_id INTO p_emp_id;
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20002, 'Invalid designation id');
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(-20003, 'An employee with this email already exists');
  END add_employee;

  PROCEDURE update_employee(p_emp_id NUMBER, p_phone VARCHAR2 DEFAULT NULL,
                            p_dept_id NUMBER DEFAULT NULL,
                            p_desig_id NUMBER DEFAULT NULL,
                            p_salary NUMBER DEFAULT NULL) IS
  BEGIN
    UPDATE employees
    SET    phone        = NVL(p_phone,   phone),
           dept_id      = NVL(p_dept_id, dept_id),
           desig_id     = NVL(p_desig_id, desig_id),
           basic_salary = NVL(p_salary,  basic_salary)
    WHERE  emp_id = p_emp_id AND status = 'ACTIVE';
    IF SQL%ROWCOUNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20004, 'Active employee not found');
    END IF;
    COMMIT;
  END update_employee;

  PROCEDURE remove_employee(p_emp_id NUMBER) IS
  BEGIN
    UPDATE employees SET status = 'INACTIVE'
    WHERE  emp_id = p_emp_id AND status = 'ACTIVE';
    IF SQL%ROWCOUNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20005, 'Active employee not found');
    END IF;
    COMMIT;
  END remove_employee;

  FUNCTION search_employees(p_name VARCHAR2 DEFAULT NULL,
                            p_dept_id NUMBER DEFAULT NULL,
                            p_desig_id NUMBER DEFAULT NULL) RETURN SYS_REFCURSOR IS
    v_cur SYS_REFCURSOR;
  BEGIN
    OPEN v_cur FOR
      SELECT emp_id, full_name, email, dept_name, designation
      FROM   v_employee_details v
      WHERE  status = 'ACTIVE'
      AND   (p_name IS NULL OR UPPER(full_name) LIKE '%' || UPPER(p_name) || '%')
      AND   (p_dept_id  IS NULL OR dept_name   = (SELECT dept_name FROM departments
                                                   WHERE dept_id = p_dept_id))
      AND   (p_desig_id IS NULL OR designation = (SELECT title FROM designations
                                                   WHERE desig_id = p_desig_id))
      ORDER BY full_name;
    RETURN v_cur;
  END search_employees;

END pkg_employee;
/
