-- Interactive console application. Start SQL*Plus or SQLcl INSIDE the sql folder:
--   sqlplus ems/Ems#12345@localhost:1521/XEPDB1      then:   @menu
SET SERVEROUTPUT ON SIZE UNLIMITED
SET VERIFY OFF
SET FEEDBACK OFF
SET DEFINE ON
PROMPT
PROMPT ==================================================
PROMPT    EMPLOYEE MANAGEMENT SYSTEM  (Oracle PL/SQL)
PROMPT ==================================================
PROMPT   1. Dashboard
PROMPT   2. List / search employees      (value 1 = name, optional)
PROMPT   3. Check in                     (value 1 = employee id)
PROMPT   4. Check out                    (value 1 = employee id)
PROMPT   5. Attendance report            (value 2 = month YYYY-MM)
PROMPT   6. Generate payroll             (value 2 = month YYYY-MM)
PROMPT   7. Payroll register             (value 2 = month YYYY-MM)
PROMPT   8. Payslip                      (value 1 = employee id, value 2 = month)
PROMPT   9. Audit log
PROMPT   0. Exit
PROMPT
ACCEPT choice CHAR DEFAULT '0' PROMPT 'Enter choice: '
ACCEPT p1 CHAR DEFAULT ' ' PROMPT 'Value 1 (name / employee id, or press Enter): '
ACCEPT p2 CHAR DEFAULT ' ' PROMPT 'Value 2 (month YYYY-MM, or press Enter for 2026-09): '
PROMPT

DECLARE
  v_c  VARCHAR2(5)   := TRIM('&choice');
  v_p1 VARCHAR2(100) := TRIM('&p1');
  v_m  DATE          := TO_DATE(NVL(TRIM('&p2'), '2026-09') || '-01', 'YYYY-MM-DD');
BEGIN
  CASE v_c
    WHEN '1' THEN pkg_ems_ui.show_dashboard;
    WHEN '2' THEN pkg_ems_ui.show_employees(v_p1);
    WHEN '3' THEN pkg_attendance.check_in(TO_NUMBER(v_p1));
                  DBMS_OUTPUT.PUT_LINE('Checked in.');
    WHEN '4' THEN pkg_attendance.check_out(TO_NUMBER(v_p1));
                  DBMS_OUTPUT.PUT_LINE('Checked out.');
    WHEN '5' THEN pkg_attendance.attendance_report(v_m);
    WHEN '6' THEN pkg_payroll.generate_payroll(v_m);
    WHEN '7' THEN pkg_ems_ui.show_payroll(v_m);
    WHEN '8' THEN pkg_payroll.print_payslip(TO_NUMBER(v_p1), v_m);
    WHEN '9' THEN pkg_ems_ui.show_audit(20);
    WHEN '0' THEN DBMS_OUTPUT.PUT_LINE('Goodbye.');
    ELSE DBMS_OUTPUT.PUT_LINE('Invalid choice.');
  END CASE;
EXCEPTION
  WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('ERROR: ' || SQLERRM);
END;
/

COLUMN nxt NEW_VALUE nxt NOPRINT
SELECT CASE WHEN TRIM('&choice') = '0' THEN 'menu_exit.sql' ELSE 'menu.sql' END AS nxt FROM dual;
@&nxt
