-- Run as SYSTEM to remove the project user and roles completely.
DROP USER ems CASCADE;
DROP ROLE hr_role;
DROP ROLE manager_role;
DROP ROLE employee_role;
