CREATE OR REPLACE PACKAGE pkg_security AS
  PROCEDURE register_user(p_emp_id NUMBER, p_username VARCHAR2,
                          p_password VARCHAR2, p_role_id NUMBER);
  FUNCTION  authenticate(p_username VARCHAR2, p_password VARCHAR2) RETURN VARCHAR2;
END pkg_security;
/
CREATE OR REPLACE PACKAGE BODY pkg_security AS

  FUNCTION hash_pwd(p_salt VARCHAR2, p_pwd VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN RAWTOHEX(STANDARD_HASH(p_salt || p_pwd, 'SHA256'));
  END hash_pwd;

  PROCEDURE register_user(p_emp_id NUMBER, p_username VARCHAR2,
                          p_password VARCHAR2, p_role_id NUMBER) IS
    v_salt VARCHAR2(32) := RAWTOHEX(SYS_GUID());
  BEGIN
    INSERT INTO users_auth(emp_id, role_id, username, salt, pwd_hash)
    VALUES (p_emp_id, p_role_id, LOWER(p_username), v_salt, hash_pwd(v_salt, p_password));
    COMMIT;
  END register_user;

  -- returns the role name on success, otherwise DENIED or LOCKED
  FUNCTION authenticate(p_username VARCHAR2, p_password VARCHAR2) RETURN VARCHAR2 IS
    v_rec  users_auth%ROWTYPE;
    v_role roles.role_name%TYPE;
  BEGIN
    SELECT * INTO v_rec FROM users_auth WHERE username = LOWER(p_username);
    IF v_rec.failed_attempts >= 5 THEN
      RETURN 'LOCKED';
    END IF;
    IF v_rec.pwd_hash = hash_pwd(v_rec.salt, p_password) THEN
      UPDATE users_auth SET failed_attempts = 0, last_login = SYSTIMESTAMP
      WHERE  user_id = v_rec.user_id;
      SELECT role_name INTO v_role FROM roles WHERE role_id = v_rec.role_id;
      COMMIT;
      RETURN v_role;
    ELSE
      UPDATE users_auth SET failed_attempts = failed_attempts + 1
      WHERE  user_id = v_rec.user_id;
      COMMIT;
      RETURN 'DENIED';
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 'DENIED';
  END authenticate;

END pkg_security;
/

-- Roles and privileges (run as the schema owner / DBA)
CREATE ROLE hr_role;
CREATE ROLE manager_role;
CREATE ROLE employee_role;
GRANT EXECUTE ON pkg_employee    TO hr_role;
GRANT EXECUTE ON pkg_payroll     TO hr_role;
GRANT EXECUTE ON pkg_performance TO hr_role, manager_role;
GRANT EXECUTE ON pkg_attendance  TO hr_role, employee_role;
GRANT SELECT  ON v_employee_details TO hr_role, manager_role, employee_role;
GRANT SELECT  ON mv_dept_payroll    TO hr_role;
