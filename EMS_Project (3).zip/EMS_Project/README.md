# Employee Management System – 100% Oracle PL/SQL (Advanced DBMS Minor Project)

Everything runs inside the Oracle database: tables, triggers, 5 business packages, a
console UI package (`pkg_ems_ui`), an interactive menu and an automatic demo.

## Folder
- `report/`   20-page project report (Word + PDF)
- `sql/`      all PL/SQL scripts
- `diagrams/` ER + architecture diagrams
- `screenshots/` put your output screenshots here

## Option A – Oracle XE on your laptop (recommended)
1. Install Oracle Database XE 21c and Oracle SQL Developer (or use SQLcl / SQL*Plus).
2. Connect as SYSTEM (localhost : 1521, service **XEPDB1**) and run `sql/00_admin_setup.sql`.
3. Connect as `ems` / `Ems#12345` (same host, port, service).
4. Open `sql/EMS_PLSQL_ALL_IN_ONE.sql` and press **F5 (Run Script)**.
   The whole project is created and the demo prints 11 steps in the Script Output / DBMS Output panel.
5. Run `sql/verify.sql` – both "invalid objects" and "errors" lists must be empty.

## Interactive menu (SQL*Plus or SQLcl)
Open a terminal **inside the sql folder** and run:

    sqlplus ems/Ems#12345@localhost:1521/XEPDB1
    SQL> @menu

Choose 1-9 (dashboard, search, check-in/out, attendance report, payroll, payslip, audit). 0 exits.

## Option B – No installation (Oracle Cloud Free Tier)
Create a free Always Free **Autonomous Database** at cloud.oracle.com, open **Database Actions > SQL**,
paste `sql/EMS_PLSQL_ALL_IN_ONE.sql` and press **Run Script (F5)**.
(Roles and the materialized view may need privileges; if those two statements fail, everything else still works.)

## Reset
Re-running the all-in-one script cleans and rebuilds the schema automatically.
To delete everything: run `sql/99_cleanup_admin.sql` as SYSTEM.

## Troubleshooting
| Error | Fix |
|---|---|
| ORA-01017 / cannot connect | Service name must be `XEPDB1` (not XE); check password |
| ORA-01031 insufficient privileges | Re-run `00_admin_setup.sql` as SYSTEM |
| ORA-01950 no privileges on tablespace | The `QUOTA UNLIMITED ON USERS` part of setup was skipped |
| ORA-01921 role name conflicts | Harmless on re-run (role already exists) |
| PLS-00201 / PLS-00905 | Compile error: run `verify.sql` or `SHOW ERRORS` and send me the message |
| No output visible | View > DBMS Output > + > choose the ems connection (or `SET SERVEROUTPUT ON`) |
